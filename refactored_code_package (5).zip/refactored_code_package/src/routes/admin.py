"""
Main admin blueprint for the Smart Campus Navigation and Facility Booking System.

This module contains the core admin functionality and shared decorators.
Specific admin features have been split into separate modules:
- admin_users.py: User management
- admin_buildings.py: Building and room management
- admin_reports.py: Reporting and policy management
"""

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.db import db
from src.models.user import User, UserRole
from src.models.building import Building, Room
from src.models.reservation import Reservation

admin = Blueprint('admin', __name__, url_prefix='/admin')

# Admin access decorator
def admin_required(f):
    """
    Decorator to restrict access to admin users only.
    
    Args:
        f: The function to decorate
        
    Returns:
        Decorated function that checks for admin role before execution
    """
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.role == UserRole.ADMINISTRATOR:
            flash('You do not have permission to access this page', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin.route('/')
@admin_required
def index():
    """
    Admin dashboard showing system overview and recent activity.
    
    Returns:
        Rendered admin dashboard template with system statistics
    """
    try:
        # Get counts for dashboard
        user_count = User.query.count()
        room_count = Room.query.count()
        building_count = Building.query.count()
        reservation_count = Reservation.query.count()
        
        # Get recent reservations
        recent_reservations = Reservation.query.order_by(
            Reservation.created_at.desc()
        ).limit(10).all()
        
        return render_template('admin/index.html',
                              user_count=user_count,
                              room_count=room_count,
                              building_count=building_count,
                              reservation_count=reservation_count,
                              recent_reservations=recent_reservations)
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return render_template('admin/index.html')

@admin.route('/system-config')
@admin_required
def system_config():
    """
    System configuration page.
    
    Returns:
        Rendered system configuration template
    """
    try:
        return render_template('admin/system_config.html')
    except Exception as e:
        flash(f'Error loading system configuration: {str(e)}', 'error')
        return redirect(url_for('admin.index'))
