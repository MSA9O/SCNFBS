"""
Building and room related models for the Smart Campus Navigation and Facility Booking System.

This module contains Building, Room, RoomType, and RoomStatus classes.
Equipment-related models have been moved to equipment.py for better organization.
"""

from src.models.db import db
from datetime import datetime
from enum import Enum

class Building(db.Model):
    """
    Building model representing campus buildings.
    
    Attributes:
        building_id: Primary key for building
        name: Name of the building
        address: Physical address of the building
        floors: Number of floors in the building
        description: Detailed description of the building
        latitude: Geographic latitude coordinate
        longitude: Geographic longitude coordinate
        image_url: URL to building image
    """
    __tablename__ = 'buildings'
    
    building_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    floors = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    
    # Relationships
    rooms = db.relationship('src.models.building.Room', backref='building', lazy=True, cascade='all, delete-orphan')
    locations = db.relationship('src.models.navigation.Location', backref='building', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        """String representation of Building object."""
        return f'<Building {self.name}>'

class RoomType(Enum):
    """
    Enumeration of possible room types.
    
    Attributes:
        CLASSROOM: Standard classroom
        LABORATORY: Laboratory space
        MEETING_ROOM: Meeting or conference room
        STUDY_SPACE: Dedicated study area
        AUDITORIUM: Large presentation space
        OFFICE: Office space
        RECREATIONAL: Recreational facility
    """
    CLASSROOM = 'classroom'
    LABORATORY = 'lab'
    MEETING_ROOM = 'meeting'
    STUDY_SPACE = 'study'
    AUDITORIUM = 'auditorium'
    OFFICE = 'office'
    RECREATIONAL = 'recreational'

class RoomStatus(Enum):
    """
    Enumeration of possible room statuses.
    
    Attributes:
        AVAILABLE: Room is available for booking
        OCCUPIED: Room is currently in use
        MAINTENANCE: Room is undergoing maintenance
        RESERVED: Room is reserved for future use
    """
    AVAILABLE = 'available'
    OCCUPIED = 'occupied'
    MAINTENANCE = 'maintenance'
    RESERVED = 'reserved'

class Room(db.Model):
    """
    Room model representing bookable spaces within buildings.
    
    Attributes:
        room_id: Primary key for room
        building_id: Foreign key referencing the building
        room_number: Room identifier within the building
        name: Descriptive name of the room
        floor: Floor number where the room is located
        capacity: Maximum number of people the room can accommodate
        room_type: Type of room (classroom, lab, etc.)
        status: Current availability status
        is_accessible: Whether the room is accessible for people with disabilities
        description: Detailed description of the room
        image_url: URL to room image
    """
    __tablename__ = 'rooms'
    
    room_id = db.Column(db.Integer, primary_key=True)
    building_id = db.Column(db.Integer, db.ForeignKey('buildings.building_id'), nullable=False)
    room_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    floor = db.Column(db.Integer, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    room_type = db.Column(db.Enum(RoomType), nullable=False)
    status = db.Column(db.Enum(RoomStatus), nullable=False, default=RoomStatus.AVAILABLE)
    is_accessible = db.Column(db.Boolean, default=False)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    
    # Relationships
    reservations = db.relationship('src.models.reservation.Reservation', backref='room', lazy=True, cascade='all, delete-orphan')
    equipment = db.relationship('src.models.equipment.RoomEquipment', backref='room', lazy=True, cascade='all, delete-orphan')
    waitlist_entries = db.relationship('src.models.reservation.WaitlistEntry', backref='room', lazy=True, cascade='all, delete-orphan')
    def __repr__(self):
        """String representation of Room object."""
        return f'<Room {self.building.name} {self.room_number}>'
    
    def check_availability(self, start_time, end_time):
        """
        Check if the room is available during the specified time period.
        
        Args:
            start_time: Datetime object representing the start of the period
            end_time: Datetime object representing the end of the period
            
        Returns:
            bool: True if the room is available, False otherwise
        """
        from src.models.reservation import Reservation, ReservationStatus
        
        try:
            overlapping_reservations = Reservation.query.filter(
                Reservation.room_id == self.room_id,
                Reservation.status != ReservationStatus.CANCELED,
                Reservation.end_time > start_time,
                Reservation.start_time < end_time
            ).count()
            
            return overlapping_reservations == 0 and self.status == RoomStatus.AVAILABLE
        except Exception as e:
            # Log the error
            print(f"Error checking room availability: {str(e)}")
            return False
