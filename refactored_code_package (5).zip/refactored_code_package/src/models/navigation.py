"""
Navigation related models for the Smart Campus Navigation and Facility Booking System.

This module contains all navigation-related models including Location, Path,
and NavigationHistory classes.
"""

from src.models.db import db
from datetime import datetime
from enum import Enum

class LocationType(Enum):
    """
    Enumeration of possible location types.
    
    Attributes:
        ROOM: Standard room location
        ENTRANCE: Building entrance
        EXIT: Building exit
        ELEVATOR: Elevator location
        STAIRS: Staircase location
        RESTROOM: Restroom location
        LANDMARK: Notable landmark for navigation
        POI: Point of interest
    """
    ROOM = 'room'
    ENTRANCE = 'entrance'
    EXIT = 'exit'
    ELEVATOR = 'elevator'
    STAIRS = 'stairs'
    RESTROOM = 'restroom'
    LANDMARK = 'landmark'
    POI = 'poi'
    PARKING = 'parking'

class Location(db.Model):
    """
    Location model representing navigation points within buildings.
    
    Attributes:
        location_id: Primary key for location
        building_id: Foreign key referencing the building
        name: Name of the location
        location_type: Type of location (room, entrance, etc.)
        floor: Floor number where the location is situated
        x_coordinate: X coordinate on the floor plan
        y_coordinate: Y coordinate on the floor plan
        description: Detailed description of the location
        is_accessible: Whether the location is accessible for people with disabilities
    """
    __tablename__ = 'locations'
    
    location_id = db.Column(db.Integer, primary_key=True)
    building_id = db.Column(db.Integer, db.ForeignKey('buildings.building_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    location_type = db.Column(db.Enum(LocationType), nullable=False)
    floor = db.Column(db.Integer, nullable=False)
    x_coordinate = db.Column(db.Float, nullable=False)
    y_coordinate = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_accessible = db.Column(db.Boolean, default=True)
    
    # Relationships
    paths_from = db.relationship('Path', 
                               foreign_keys='Path.start_location_id',
                               backref='from_location_obj', 
                               lazy=True,
                               cascade='all, delete-orphan')
    paths_to = db.relationship('Path', 
                             foreign_keys='Path.end_location_id',
                             backref='to_location_obj',
                             lazy=True,
                             cascade='all, delete-orphan')
    
    def __repr__(self):
        """String representation of Location object."""
        return f'<Location {self.name}>'
    
    @staticmethod
    def get_nearest(building_id, floor, x, y):
        """
        Find the nearest location to the given coordinates.
        
        Args:
            building_id: ID of the building to search in
            floor: Floor number to search on
            x: X coordinate to find nearest location to
            y: Y coordinate to find nearest location to
            
        Returns:
            Location: Nearest location object or None if error occurs
        """
        try:
            # Calculate Euclidean distance for all locations on the floor
            locations = Location.query.filter_by(
                building_id=building_id,
                floor=floor
            ).all()
            
            if not locations:
                return None
                
            # Find location with minimum distance
            nearest = min(
                locations,
                key=lambda loc: ((loc.x_coordinate - x) ** 2 + (loc.y_coordinate - y) ** 2) ** 0.5
            )
            
            return nearest
        except Exception as e:
            # Log the error
            print(f"Error finding nearest location: {str(e)}")
            return None

class Path(db.Model):
    __tablename__ = 'paths'
    
    path_id = db.Column(db.Integer, primary_key=True)
    start_location_id = db.Column(db.Integer, db.ForeignKey('locations.location_id'), nullable=False) # CHECK THIS LINE
    end_location_id = db.Column(db.Integer, db.ForeignKey('locations.location_id'), nullable=False)   # CHECK THIS LINE
    distance_meters = db.Column(db.Float, nullable=False) 
    estimated_time_seconds = db.Column(db.Integer, nullable=False)
    is_accessible = db.Column(db.Boolean, default=True) 
    path_type = db.Column(db.String(50), nullable=False)
    path_geometry = db.Column(db.Text, nullable=True)
    instructions_summary = db.Column(db.Text, nullable=True)
    steps = db.relationship('src.models.navigation.NavigationStep', backref='path', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        """String representation of Path object."""
        return f'<Path {self.start_location_id} to {self.end_location_id}>'

class NavigationHistory(db.Model):
    """
    NavigationHistory model for tracking user navigation requests.
    
    Attributes:
        history_id: Primary key for navigation history entry
        user_id: Foreign key referencing the user who made the navigation request
        from_location_id: Foreign key referencing the starting location
        to_location_id: Foreign key referencing the destination location
        timestamp: When the navigation request was made
        is_accessible_route: Whether an accessible route was requested
        completed: Whether the navigation was completed
    """
    __tablename__ = 'navigation_history'
    
    history_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    from_location_id = db.Column(db.Integer, db.ForeignKey('locations.location_id'), nullable=False)
    to_location_id = db.Column(db.Integer, db.ForeignKey('locations.location_id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    is_accessible_route = db.Column(db.Boolean, default=False)
    completed = db.Column(db.Boolean, default=False)
    
    # Relationships
    from_location = db.relationship('src.models.navigation.Location', foreign_keys=[from_location_id])
    to_location = db.relationship('src.models.navigation.Location', foreign_keys=[to_location_id], backref="nav_history_to")
    def __repr__(self):
        """String representation of NavigationHistory object."""
        return f'<NavigationHistory {self.history_id}>'

class NavigationStep(db.Model):
    """
    NavigationStep model representing individual steps or instructions in a navigation path.

    Attributes:
        step_id: Primary key for navigation step
        path_id: Foreign key referencing the path this step belongs to
        step_number: Order of this step in the path
        instruction: Textual instruction for this step (e.g., "Turn left at the hallway")
        distance: Distance covered in this step (in meters)
        estimated_time: Estimated time for this step (in seconds)
        icon: Optional icon name for visual aid (e.g., 'turn-left', 'elevator')
    """
    __tablename__ = 'navigation_steps'

    step_id = db.Column(db.Integer, primary_key=True)
    path_id = db.Column(db.Integer, db.ForeignKey('paths.path_id'), nullable=False)
    step_number = db.Column(db.Integer, nullable=False)
    instruction = db.Column(db.Text, nullable=False)
    distance = db.Column(db.Float, nullable=True) # in meters
    estimated_time = db.Column(db.Integer, nullable=True) # in seconds
    icon = db.Column(db.String(50), nullable=True)

    def __repr__(self):
        return f'<NavigationStep {self.path_id}-{self.step_number}>'

class AccessPoint(db.Model):
    """
    AccessPoint model representing accessible features like ramps, elevators, accessible entrances.

    Attributes:
        access_point_id: Primary key for the access point
        location_id: Foreign key referencing the location of this access point
        type: Type of access point (e.g., 'ramp', 'elevator', 'accessible_door')
        description: Detailed description of the access point
        is_operational: Whether the access point is currently operational
    """
    __tablename__ = 'access_points'
    access_point_id = db.Column(db.Integer, primary_key=True)
    location_id = db.Column(db.Integer, db.ForeignKey('locations.location_id'), nullable=False)
    type = db.Column(db.String(50), nullable=False) # e.g., RAMP, ELEVATOR, ACCESSIBLE_ENTRANCE
    description = db.Column(db.Text, nullable=True)
    is_operational = db.Column(db.Boolean, default=True)

    location = db.relationship('Location', backref='access_points')

    def __repr__(self):
        return f'<AccessPoint {self.type} at Location {self.location_id}>'