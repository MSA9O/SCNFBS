"""
Main application module for the Smart Campus Navigation and Facility Booking System.

This module initializes the Flask application, configures database connections,
registers blueprints, and sets up error handlers.
"""
from flask_migrate import Migrate
from flask import Flask, render_template, flash, redirect, url_for
from flask_login import LoginManager
import os
from src.models.db import db
# Import User and UserRole for the default admin creation, but specific model files need to be imported too
from src.models.user import User, UserRole
from src.routes.user import user_routes_blueprint # Renamed to avoid conflict
from src.routes.navigation import navigation as navigation_blueprint

# --- START OF CRITICAL CHANGE ---
# Explicitly import all model modules to ensure SQLAlchemy discovers them
# before db.init_app() or db.create_all()
from src.models import user # Though User is imported above, importing the module is good practice
from src.models import building
from src.models import equipment # <<< THIS IS THE KEY IMPORT FOR THE CURRENT ERROR
from src.models import reservation
from src.models import navigation
# --- END OF CRITICAL CHANGE ---


def create_app():
    """
    Create and configure the Flask application.
    
    Returns:
        Flask: Configured Flask application instance
    """
    app = Flask(__name__)
    
    # Configure application
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-for-testing')
    
    # Configure database - MySQL configuration with mysql.connector
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:Mohamed%40123@localhost/scnfs_project'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Initialize extensions
    db.init_app(app) # Models should be known to SQLAlchemy's metadata by now
    migrate = Migrate(app, db)
    
    # Initialize login manager
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'  # type: ignore
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        """
        Load user by ID for Flask-Login.
        
        Args:
            user_id: User ID to load
            
        Returns:
            User: User object or None if not found
        """
        try:
            # User model is already imported at the top of the file
            return db.session.get(User, int(user_id))
        except Exception as e:
            print(f"Error loading user: {str(e)}")
            return None
    
    # Register blueprints and other app context items
    with app.app_context():
        # Import blueprints
        from src.routes.auth import auth
        from src.routes.admin import admin
        from src.routes.admin_users import admin_users
        from src.routes.admin_buildings import admin_buildings
        from src.routes.admin_reports import admin_reports
        from src.routes.booking import booking
        from src.routes.navigation import navigation as navigation_blueprint
        from src.routes.user import user_routes_blueprint # Renamed to avoid conflict with 'user' model module
        
        # Register blueprints
        app.register_blueprint(auth)
        app.register_blueprint(admin)
        app.register_blueprint(admin_users)
        app.register_blueprint(admin_buildings)
        app.register_blueprint(admin_reports)
        app.register_blueprint(booking)
        app.register_blueprint(navigation_blueprint, url_prefix='/navigation')
        app.register_blueprint(user_routes_blueprint, name='user_routes') # Give it a unique name if 'user' is too generic
        
        # Register error handlers
        @app.errorhandler(404)
        def page_not_found(e):
            """Handle 404 errors."""
            return render_template('errors/404.html'), 404

        @app.errorhandler(500)
        def internal_server_error(e):
            """Handle 500 errors."""
            return render_template('errors/500.html'), 500
        
        # Create database tables if they don't exist
        try:
            db.create_all() # This is where mappers are finalized if not already
            
            # Create admin user if no users exist
            # User model is already imported at the top
            if User.query.count() == 0:
                # Need to import Administrator model if creating its profile instance
                from src.models.user import Administrator 
                
                admin_user_obj = User( # Renamed variable to avoid conflict
                    username='admin',
                    email='admin@example.com',
                    password='admin123',
                    role=UserRole.ADMINISTRATOR
                )
                db.session.add(admin_user_obj)
                db.session.flush() # Get the admin_user_obj.user_id

                # Create Administrator profile
                admin_profile = Administrator(user_id=admin_user_obj.user_id, admin_level="superuser")
                db.session.add(admin_profile)

                db.session.commit()
                print("Created default admin user with profile")
        except Exception as e:
            print(f"Error during database initialization: {str(e)}")
            # db.session.rollback() # Good practice if an error occurs during commit
        
        @app.route('/')
        def index():
            """Main application index route."""
            return render_template('index.html')
    
    return app

# Create the application instance
# This line should ideally not be here if 'app' is defined inside create_app for factory pattern
# app = create_app() 
# Instead, the instance is created when run.py or wsgi.py calls create_app()

if __name__ == '__main__':
    # Create the application instance for direct run
    app_instance = create_app()
    # Run the application in debug mode if executed directly
    app_instance.run(debug=True, host='0.0.0.0')