"""
Equipment related models for the Smart Campus Navigation and Facility Booking System.

This module contains all equipment-related models that were previously part of building.py,
including Equipment, EquipmentStatus, and RoomEquipment classes.
"""

from src.models.db import db
from enum import Enum

class EquipmentStatus(Enum):
    """
    Enumeration of possible equipment statuses.
    
    Attributes:
        OPERATIONAL: Equipment is functioning normally
        MAINTENANCE: Equipment is undergoing maintenance
        OUT_OF_ORDER: Equipment is not functioning and unavailable for use
    """
    OPERATIONAL = 'operational'
    MAINTENANCE = 'maintenance'
    OUT_OF_ORDER = 'out_of_order'

class Equipment(db.Model):
    """
    Equipment model representing various equipment items available in rooms.
    
    Attributes:
        equipment_id: Primary key for equipment
        name: Name of the equipment
        description: Detailed description of the equipment
        status: Current operational status of the equipment
    """
    __tablename__ = 'equipment'
    
    equipment_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    status = db.Column(db.Enum(EquipmentStatus), nullable=False, default=EquipmentStatus.OPERATIONAL)
    
    # Relationships
    room_equipment = db.relationship('src.models.equipment.RoomEquipment', backref='equipment', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        """String representation of Equipment object."""
        return f'<Equipment {self.name}>'

class RoomEquipment(db.Model):
    """
    Junction model representing equipment assigned to specific rooms.
    
    Attributes:
        room_equipment_id: Primary key for room equipment relationship
        room_id: Foreign key referencing the room
        equipment_id: Foreign key referencing the equipment
        quantity: Number of this equipment item in the room
    """
    __tablename__ = 'room_equipment'
    
    room_equipment_id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('rooms.room_id'), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.equipment_id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    
    def __repr__(self):
        return f'<RoomEquipment {self.room_id}:{self.equipment_id}>'
