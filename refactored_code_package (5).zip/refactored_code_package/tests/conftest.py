"""
Test configuration and utilities for the Smart Campus Navigation and Facility Booking System.

This module provides test fixtures and helper functions for unit and integration testing.
"""

import pytest
from src.main import create_app
from src.models.db import db
from src.models.user import User, UserRole, Administrator
import os
import tempfile

@pytest.fixture
def app():
    """Create and configure a Flask app for testing."""
    # Create a temporary file to isolate the database for each test
    db_fd, db_path = tempfile.mkstemp()
    
    app = create_app()
    app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': f'sqlite:///{db_path}',
        'WTF_CSRF_ENABLED': False
    })
    
    # Create the database and the database tables
    with app.app_context():
        db.create_all()
        
        # Create test admin user
        admin = User(
            username='testadmin',
            email='testadmin@example.com',
            password='password',
            role=UserRole.ADMINISTRATOR
        )
        db.session.add(admin)
        db.session.commit()
        
        # Create admin profile
        admin_profile = Administrator(
            user_id=admin.user_id,
            admin_level='system',
            department='IT'
        )
        db.session.add(admin_profile)
        db.session.commit()
    
    yield app
    
    # Close and remove the temporary database
    os.close(db_fd)
    os.unlink(db_path)

@pytest.fixture
def client(app):
    """A test client for the app."""
    return app.test_client()

@pytest.fixture
def runner(app):
    """A test CLI runner for the app."""
    return app.test_cli_runner()

@pytest.fixture
def auth(client):
    """Authentication helper for tests."""
    class AuthActions:
        def login(self, username='testadmin', password='password'):
            return client.post(
                '/auth/login',
                data={'username': username, 'password': password}
            )
            
        def logout(self):
            return client.get('/auth/logout')
    
    return AuthActions()
