# Smart Campus Navigation and Facility Booking System (SCNFBS)

## Overview

The Smart Campus Navigation and Facility Booking System (SCNFBS) is a comprehensive web application designed to streamline campus navigation and facility booking processes. The system allows students, faculty, and staff to easily find their way around campus buildings and book rooms and facilities as needed.

## Features

- **User Management**: Role-based access control for administrators, faculty/staff, and students
- **Building & Room Management**: Comprehensive management of campus buildings and rooms
- **Navigation System**: Indoor navigation with accessible route options
- **Booking System**: Room reservation with policy enforcement and waitlist capabilities
- **Reporting**: Usage statistics and administrative reports

## Technology Stack

- **Backend**: Python with Flask framework
- **Database**: MySQL
- **Frontend**: HTML, CSS, JavaScript

## Project Structure

```
src/
├── models/             # Database models
│   ├── building.py     # Building and room models
│   ├── db.py           # Database configuration
│   ├── equipment.py    # Equipment-related models
│   ├── navigation.py   # Navigation-related models
│   ├── reservation.py  # Reservation and booking policy models
│   └── user.py         # User and role models
├── routes/             # Route handlers
│   ├── admin.py        # Core admin functionality
│   ├── admin_buildings.py  # Building management routes
│   ├── admin_reports.py    # Reporting routes
│   ├── admin_users.py      # User management routes
│   ├── auth.py         # Authentication routes
│   ├── booking.py      # Booking routes
│   ├── navigation.py   # Navigation routes
│   └── user.py         # User profile routes
├── static/             # Static assets (CSS, JS, images)
├── templates/          # HTML templates
└── utils.py            # Utility functions
├── main.py             # Application entry point
```

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- MySQL 8.0 or higher
- pip (Python package manager)

### Installation

1. **Clone the repository**

```bash
git clone https://github.com/yourusername/scnfbs.git
cd scnfbs
```

2. **Create a virtual environment**

```bash
python -m venv venv
```

3. **Activate the virtual environment**

On Windows:
```bash
venv\Scripts\activate
```

On macOS/Linux:
```bash
source venv/bin/activate
```

4. **Install dependencies**

```bash
pip install -r requirements.txt
```

5. **Configure the database**

Create a MySQL database:
```sql
CREATE DATABASE tictactoe;
```

6. **Set environment variables**

Create a `.env` file in the project root with the following content:
```
SECRET_KEY=your_secret_key_here
```

7. **Initialize the database**

```bash
python -m src.main
```

8. **Run the application**

```bash
python -m src.main
```

The application will be available at http://localhost:5000

### Default Admin Account

After initialization, a default admin account is created:
- Username: admin
- Email: admin@example.com
- Password: admin123

**Important**: Change the default admin password immediately after first login.

## MySQL Connection

The application uses MySQL with the following connection parameters:

```python
mysql.connector.connect(
    host="localhost",
    user="root",
    password="Mohamed@123",
    database="tictactoe"
)
```

You can modify these settings in `src/models/db.py` if needed.

## Testing

To run the tests:

```bash
pytest
```

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit your changes: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin feature-name`
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
