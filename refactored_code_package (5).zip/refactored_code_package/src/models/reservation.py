"""
Reservation related models for the Smart Campus Navigation and Facility Booking System.

This module contains all reservation-related models including Reservation,
BookingPolicy, and WaitlistEntry classes.
"""

from src.models.db import db
from datetime import datetime
from enum import Enum

class ReservationStatus(Enum):
    """
    Enumeration of possible reservation statuses.
    
    Attributes:
        PENDING: Reservation is awaiting confirmation
        CONFIRMED: Reservation has been confirmed
        CANCELED: Reservation has been canceled
        COMPLETED: Reservation period has passed and was used
        DENIED: Reservation request was denied
    """
    PENDING = 'pending'
    CONFIRMED = 'confirmed'
    CANCELED = 'canceled'
    COMPLETED = 'completed'
    DENIED = 'denied'

class Reservation(db.Model):
    """
    Reservation model representing room bookings.
    
    Attributes:
        reservation_id: Primary key for reservation
        user_id: Foreign key referencing the user who made the reservation
        room_id: Foreign key referencing the reserved room
        start_time: Start time of the reservation
        end_time: End time of the reservation
        purpose: Purpose or reason for the reservation
        status: Current status of the reservation
        created_at: Timestamp when the reservation was created
        updated_at: Timestamp when the reservation was last updated
        notes: Additional notes or comments about the reservation
    """
    __tablename__ = 'reservations'
    
    reservation_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('rooms.room_id'), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    purpose = db.Column(db.String(255), nullable=False)
    status = db.Column(db.Enum(ReservationStatus), nullable=False, default=ReservationStatus.PENDING)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        """String representation of Reservation object."""
        return f'<Reservation {self.reservation_id}>'
    
    def cancel(self):
        """
        Cancel this reservation if it's not already completed or canceled.
        
        Returns:
            bool: True if cancellation was successful, False otherwise
        """
        try:
            if self.status not in [ReservationStatus.COMPLETED, ReservationStatus.CANCELED]:
                self.status = ReservationStatus.CANCELED
                self.updated_at = datetime.utcnow()
                return True
            return False
        except Exception as e:
            # Log the error
            print(f"Error canceling reservation: {str(e)}")
            return False
    
    def modify(self, start_time, end_time):
        """
        Modify reservation time if the new time slot is available.
        
        Args:
            start_time: New start time for the reservation
            end_time: New end time for the reservation
            
        Returns:
            bool: True if modification was successful, False otherwise
        """
        try:
            if self.status not in [ReservationStatus.COMPLETED, ReservationStatus.CANCELED]:
                # Check if the new time slot is available
                if self.room.check_availability(start_time, end_time):
                    self.start_time = start_time
                    self.end_time = end_time
                    self.updated_at = datetime.utcnow()
                    return True
            return False
        except Exception as e:
            # Log the error
            print(f"Error modifying reservation: {str(e)}")
            return False

class BookingPolicy(db.Model):
    """
    BookingPolicy model defining rules for room reservations.
    
    Attributes:
        policy_id: Primary key for policy
        name: Name of the policy
        description: Detailed description of the policy
        max_duration_minutes: Maximum allowed booking duration in minutes
        advance_booking_days: Maximum days in advance a booking can be made
        start_time: Earliest time of day bookings can start
        end_time: Latest time of day bookings can end
        applicable_roles: Comma-separated list of user roles this policy applies to
        applicable_room_types: Comma-separated list of room types this policy applies to
        created_by: Foreign key referencing the user who created the policy
        created_at: Timestamp when the policy was created
        updated_at: Timestamp when the policy was last updated
    """
    __tablename__ = 'booking_policies'
    
    policy_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    max_duration_minutes = db.Column(db.Integer, nullable=False)
    advance_booking_days = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    applicable_roles = db.Column(db.String(255), nullable=True)  # Comma-separated roles
    applicable_room_types = db.Column(db.String(255), nullable=True)  # Comma-separated room types
    created_by = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    
    def __repr__(self):
        """String representation of BookingPolicy object."""
        return f'<BookingPolicy {self.name}>'
    
    def is_allowed(self, user, room, start_time, end_time):
        """
        Check if booking is allowed under this policy.
        
        Args:
            user: User attempting to make the booking
            room: Room being booked
            start_time: Requested start time
            end_time: Requested end time
            
        Returns:
            bool: True if booking is allowed under this policy, False otherwise
        """
        try:
            # Check if policy applies to this user role
            if self.applicable_roles and user.role.value not in self.applicable_roles.split(','):
                return False
            
            # Check if policy applies to this room type
            if self.applicable_room_types and room.room_type.value not in self.applicable_room_types.split(','):
                return False
            
            # Check booking duration
            duration_minutes = (end_time - start_time).total_seconds() / 60
            if duration_minutes > self.max_duration_minutes:
                return False
            
            # Check advance booking limit
            advance_days = (start_time.date() - datetime.utcnow().date()).days
            if advance_days > self.advance_booking_days:
                return False
            
            # Check booking time range
            booking_start_time = start_time.time()
            booking_end_time = end_time.time()
            if booking_start_time < self.start_time or booking_end_time > self.end_time:
                return False
            
            return True
        except Exception as e:
            # Log the error
            print(f"Error checking booking policy: {str(e)}")
            return False

class WaitlistEntry(db.Model):
    """
    WaitlistEntry model for tracking room booking waitlist requests.
    
    Attributes:
        waitlist_id: Primary key for waitlist entry
        user_id: Foreign key referencing the user on the waitlist
        room_id: Foreign key referencing the requested room
        requested_start_time: Requested start time for the reservation
        requested_end_time: Requested end time for the reservation
        created_at: Timestamp when the waitlist entry was created
        priority: Priority level of the request (higher number = higher priority)
        status: Current status of the waitlist entry (waiting, notified, expired)
    """
    __tablename__ = 'waitlist_entries'
    
    waitlist_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('rooms.room_id'), nullable=False)
    requested_start_time = db.Column(db.DateTime, nullable=False)
    requested_end_time = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    priority = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(20), default='waiting')
    
    def __repr__(self):
        """String representation of WaitlistEntry object."""
        return f'<WaitlistEntry {self.waitlist_id}>'
    
    def notify_if_available(self):
        """
        Check if the requested time slot is now available and update status.
        
        Returns:
            bool: True if room is available and status updated, False otherwise
        """
        try:
            if self.status == 'waiting' and self.room.check_availability(
                self.requested_start_time, self.requested_end_time):
                self.status = 'notified'
                # In a real implementation, this would trigger an email notification
                return True
            return False
        except Exception as e:
            # Log the error
            print(f"Error checking waitlist availability: {str(e)}")
            return False
