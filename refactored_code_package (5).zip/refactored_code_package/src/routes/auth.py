from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from src.models.db import db
from src.models.user import User, UserRole, Administrator, FacultyStaff, Student
from werkzeug.security import generate_password_hash, check_password_hash

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            user.last_login = db.func.now()
            db.session.commit()
            
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            return redirect(url_for('index'))
        
        flash('Invalid username or password', 'error')
    
    return render_template('auth/login.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        
        # Validate input
        if not username or not email or not password or not confirm_password or not role:
            flash('All fields are required', 'error')
            return render_template('auth/register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('auth/register.html')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('auth/register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('auth/register.html')
        
        # Create new user
        try:
            user_role = UserRole(role)
            new_user = User(username=username, email=email, password=password, role=user_role)
            db.session.add(new_user)
            db.session.flush()  # Get user_id without committing
            
            # Create role-specific profile
            if user_role == UserRole.STUDENT:
                student_number = request.form.get('student_number')
                major = request.form.get('major')
                graduation_year = request.form.get('graduation_year')
                
                if not student_number or not major:
                    flash('Student number and major are required', 'error')
                    return render_template('auth/register.html')
                
                student_profile = Student(
                    user_id=new_user.user_id,
                    student_number=student_number,
                    major=major,
                    graduation_year=graduation_year
                )
                db.session.add(student_profile)

            elif user_role == UserRole.FACULTY_STAFF:
                department = request.form.get('department')
                position = request.form.get('position')
                
                if not department or not position:
                    flash('Department and position are required', 'error')
                    return render_template('auth/register.html')

                faculty_profile = FacultyStaff(
                    user_id=new_user.user_id,
                    department=department,
                    position=position
                )
                db.session.add(faculty_profile)
                
                
            elif user_role == UserRole.ADMINISTRATOR:
                # For this example, let's assume an admin_level can be set if provided,
                # or a default is applied. More complex admin setup might be manual or seeded.
                admin_level = request.form.get('admin_level', 'default_admin_level') # Expect 'admin_level' from form
                admin_profile = Administrator(
                    user_id=new_user.user_id,
                    admin_level=admin_level
                )
                db.session.add(admin_profile)
                
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    # Pass UserRole to template for role dropdown
    return render_template('auth/register.html', UserRole=UserRole)

# Removed /profile and /profile/edit from auth.py as they are better placed in user.py
# @auth.route('/profile')
# @login_required
# def profile():
#     return render_template('auth/profile.html') # Consider moving to user blueprint's template

# @auth.route('/profile/edit', methods=['GET', 'POST'])
# @login_required
def edit_profile():
    if request.method == 'POST':
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        
        if not email:
            flash('Email is required', 'error')
            return render_template('auth/edit_profile.html')        
        # Check if email already exists for another user
        existing_user = User.query.filter_by(email=email).first()
        if existing_user and existing_user.user_id != current_user.user_id:
            flash('Email already exists', 'error')
            return render_template('auth/edit_profile.html')
        
        try:
            current_user.email = email
            current_user.phone_number = phone_number
            
            # Update role-specific information
            if current_user.role == UserRole.STUDENT and current_user.student:
                current_user.student.major = request.form.get('major')
                current_user.student.graduation_year = request.form.get('graduation_year')
                
            elif current_user.role == UserRole.FACULTY_STAFF and current_user.faculty_staff:
                current_user.faculty_staff.department = request.form.get('department')
                current_user.faculty_staff.position = request.form.get('position')
                current_user.faculty_staff.office_location = request.form.get('office_location')
            
            db.session.commit()
            flash('Profile updated successfully', 'success')
            return redirect(url_for('auth.profile'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    return render_template('auth/edit_profile.html')

@auth.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required', 'error')
            return render_template('auth/change_password.html')
        
        if not current_user.check_password(current_password):
            flash('Current password is incorrect', 'error')
            return render_template('auth/change_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match', 'error')
            return render_template('auth/change_password.html')
        
        try:
            current_user.set_password(new_password)
            db.session.commit()
            flash('Password changed successfully', 'success')
            return redirect(url_for('user_routes.profile'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    return render_template('auth/change_password.html')
