"""
Integration tests for the Smart Campus Navigation and Facility Booking System.

This module contains tests for the integration between different components of the system.
"""

import pytest
from datetime import datetime, timedelta

def test_user_reservation_integration(app, client, auth):
    """Test the integration between users and reservations."""
    with app.app_context():
        from src.models.db import db
        from src.models.user import User, UserRole
        from src.models.building import Building, Room, RoomType, RoomStatus
        from src.models.reservation import Reservation, ReservationStatus
        
        # Create test data
        building = Building(name='Integration Test Building', address='123 Int St', floors=2)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='I101',
            name='Integration Test Room',
            floor=1,
            capacity=20,
            room_type=RoomType.MEETING_ROOM,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        # Use existing test admin user from fixture
        user = User.query.filter_by(username='testadmin').first()
        
        # Create a reservation
        start_time = datetime.now() + timedelta(days=1)
        end_time = start_time + timedelta(hours=1)
        
        reservation = Reservation(
            user_id=user.user_id,
            room_id=room.room_id,
            start_time=start_time,
            end_time=end_time,
            purpose='Integration test',
            status=ReservationStatus.CONFIRMED
        )
        
        db.session.add(reservation)
        db.session.commit()
        
        # Test that the reservation is linked to the user
        user_reservations = Reservation.query.filter_by(user_id=user.user_id).all()
        assert len(user_reservations) > 0
        assert any(r.reservation_id == reservation.reservation_id for r in user_reservations)
        
        # Test that the reservation is linked to the room
        room_reservations = Reservation.query.filter_by(room_id=room.room_id).all()
        assert len(room_reservations) > 0
        assert any(r.reservation_id == reservation.reservation_id for r in room_reservations)
        
        # Test that the room shows as unavailable during the reservation time
        assert room.check_availability(start_time, end_time) == False
        
        # Test that the room is available at a different time
        different_start = start_time + timedelta(days=1)
        different_end = different_start + timedelta(hours=1)
        assert room.check_availability(different_start, different_end) == True

def test_utils_integration(app):
    """Test the integration with utility functions."""
    with app.app_context():
        from src.utils import validate_email, validate_date_range, validate_time_range, sanitize_input
        
        # Test email validation
        assert validate_email('test@example.com') == True
        assert validate_email('invalid-email') == False
        
        # Test date range validation
        valid, _ = validate_date_range('2025-06-01', '2025-06-05', max_days=7)
        assert valid == True
        
        invalid, error = validate_date_range('2025-06-10', '2025-06-05')
        assert invalid == False
        assert "Start date must be before end date" in error
        
        # Test time range validation
        valid, _ = validate_time_range('09:00', '10:30', min_duration_minutes=30)
        assert valid == True
        
        invalid, error = validate_time_range('10:00', '09:00')
        assert invalid == False
        assert "Start time must be before end time" in error
        
        # Test input sanitization
        assert sanitize_input('<script>alert("XSS")</script>') == 'alert("XSS")'
        assert sanitize_input('Normal text') == 'Normal text'

def test_database_connection(app):
    """Test the database connection and operations."""
    with app.app_context():
        from src.models.db import db, get_db_connection
        
        # Test SQLAlchemy connection
        try:
            result = db.session.execute("SELECT 1").scalar()
            assert result == 1
        except Exception as e:
            pytest.fail(f"SQLAlchemy database connection failed: {str(e)}")
        
        # Note: We can't test the direct MySQL connector in unit tests
        # as it requires an actual MySQL server, but we can verify the function exists
        assert callable(get_db_connection)

def test_error_handling(app, client):
    """Test error handling for invalid operations."""
    with app.app_context():
        from src.utils import safe_db_operation
        from src.models.user import User
        
        # Test safe database operation with success
        def successful_operation():
            return "success"
            
        success, result = safe_db_operation(successful_operation, success_message="Operation succeeded")
        assert success == True
        assert result == "success"
        
        # Test safe database operation with failure
        def failing_operation():
            raise ValueError("Test error")
            
        success, result = safe_db_operation(failing_operation, error_message="Operation failed")
        assert success == False
        assert result is None
