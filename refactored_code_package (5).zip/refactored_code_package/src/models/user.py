"""
User model classes for the Smart Campus Navigation and Facility Booking System.

This module contains all user-related models including User base class and role-specific
subclasses (Administrator, FacultyStaff, Student).
"""

from src.models.db import db
from datetime import datetime
from enum import Enum
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class UserRole(Enum):
    """
    Enumeration of possible user roles in the system.
    
    Attributes:
        ADMINISTRATOR: System administrator with full access
        FACULTY_STAFF: Faculty or staff member with elevated privileges
        STUDENT: Student with standard access privileges
    """
    ADMINISTRATOR = 'admin'
    FACULTY_STAFF = 'faculty'
    STUDENT = 'student'

class User(db.Model, UserMixin):
    """
    Base user model representing all users in the system.
    
    Attributes:
        user_id: Primary key for user
        username: Unique username for login
        email: Unique email address
        password_hash: Hashed password for security
        role: User role (admin, faculty, student)
        phone_number: Contact phone number
        created_at: Account creation timestamp
        last_login: Last login timestamp
        status: Account status (active, inactive, suspended)
    """
    __tablename__ = 'users'
    
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False)
    phone_number = db.Column(db.String(20), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='active')
    
    # Relationships
    administrator = db.relationship('src.models.user.Administrator', backref='user', uselist=False, cascade='all, delete-orphan')
    faculty_staff = db.relationship('src.models.user.FacultyStaff', backref='user', uselist=False, cascade='all, delete-orphan')
    student = db.relationship('src.models.user.Student', backref='user', uselist=False, cascade='all, delete-orphan')
    reservations = db.relationship('src.models.reservation.Reservation', backref='user', lazy=True, cascade='all, delete-orphan')
    waitlist_entries = db.relationship('src.models.reservation.WaitlistEntry', backref='user', lazy=True, cascade='all, delete-orphan')

    def __init__(self, username, email, password, role):
        """
        Initialize a new User instance.
        
        Args:
            username: Unique username for the user
            email: Email address for the user
            password: Plain text password (will be hashed)
            role: UserRole enum value
        """
        self.username = username
        self.email = email
        self.set_password(password)
        self.role = role
    
    def set_password(self, password):
        """
        Set the user's password by generating a secure hash.
        
        Args:
            password: Plain text password to hash
        """
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """
        Verify a password against the stored hash.
        
        Args:
            password: Plain text password to check
            
        Returns:
            bool: True if password matches, False otherwise
        """
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        """
        Get the user ID as a string for Flask-Login.
        
        Returns:
            str: User ID as string
        """
        return str(self.user_id)
    
    def __repr__(self):
        """String representation of User object."""
        return f'<User {self.username}>'

class Administrator(db.Model):
    """
    Administrator model for users with administrative privileges.
    
    Attributes:
        admin_id: Primary key for administrator
        user_id: Foreign key referencing the base user
        admin_level: Level of administrative access
        department: Department the administrator belongs to
    """
    __tablename__ = 'administrators'
    
    admin_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    admin_level = db.Column(db.String(20), nullable=False)
    department = db.Column(db.String(50), nullable=True)
    
    def __repr__(self):
        """String representation of Administrator object."""
        return f'<Administrator {self.admin_id}>'

class FacultyStaff(db.Model):
    """
    Faculty/Staff model for academic and support staff users.
    
    Attributes:
        faculty_id: Primary key for faculty/staff
        user_id: Foreign key referencing the base user
        department: Academic or administrative department
        position: Job title or position
        office_location: Office room or location
    """
    __tablename__ = 'faculty_staff'
    
    faculty_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    department = db.Column(db.String(50), nullable=False)
    position = db.Column(db.String(50), nullable=False)
    office_location = db.Column(db.String(50), nullable=True)
    
    def __repr__(self):
        """String representation of FacultyStaff object."""
        return f'<FacultyStaff {self.faculty_id}>'

class Student(db.Model):
    """
    Student model for student users.
    
    Attributes:
        student_id: Primary key for student
        user_id: Foreign key referencing the base user
        student_number: Unique student identification number
        major: Field of study or major
        graduation_year: Expected year of graduation
    """
    __tablename__ = 'students'
    
    student_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    student_number = db.Column(db.String(20), unique=True, nullable=False)
    major = db.Column(db.String(50), nullable=False)
    graduation_year = db.Column(db.Integer, nullable=True)
    
    def __repr__(self):
        """String representation of Student object."""
        return f'<Student {self.student_number}>'
