"""
Unit tests for user models in the Smart Campus Navigation and Facility Booking System.

This module contains tests for the User, UserRole, and related models.
"""

import pytest
from src.models.user import User, UserRole, Administrator, FacultyStaff, Student
from werkzeug.security import check_password_hash

def test_user_creation(app):
    """Test that a user can be created with correct attributes."""
    with app.app_context():
        # Create a test user
        user = User(
            username='testuser',
            email='test@example.com',
            password='password123',
            role=UserRole.STUDENT
        )
        
        # Check attributes
        assert user.username == 'testuser'
        assert user.email == 'test@example.com'
        assert user.role == UserRole.STUDENT
        assert check_password_hash(user.password_hash, 'password123')
        assert user.status == 'active'

def test_user_password(app):
    """Test password setting and checking functionality."""
    with app.app_context():
        # Create a test user
        user = User(
            username='passwordtest',
            email='password@example.com',
            password='original',
            role=UserRole.STUDENT
        )
        
        # Test original password
        assert user.check_password('original')
        assert not user.check_password('wrong')
        
        # Change password and test again
        user.set_password('newpassword')
        assert user.check_password('newpassword')
        assert not user.check_password('original')

def test_user_roles(app):
    """Test that different user roles can be assigned correctly."""
    with app.app_context():
        # Create users with different roles
        admin = User(
            username='roleadmin',
            email='admin@example.com',
            password='pass',
            role=UserRole.ADMINISTRATOR
        )
        
        faculty = User(
            username='rolefaculty',
            email='faculty@example.com',
            password='pass',
            role=UserRole.FACULTY_STAFF
        )
        
        student = User(
            username='rolestudent',
            email='student@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        
        # Check roles
        assert admin.role == UserRole.ADMINISTRATOR
        assert faculty.role == UserRole.FACULTY_STAFF
        assert student.role == UserRole.STUDENT
        
        # Check role values
        assert admin.role.value == 'admin'
        assert faculty.role.value == 'faculty'
        assert student.role.value == 'student'

def test_administrator_profile(app):
    """Test that administrator profile can be created and linked to a user."""
    with app.app_context():
        # Create a test admin user
        admin = User(
            username='adminprofile',
            email='adminprofile@example.com',
            password='pass',
            role=UserRole.ADMINISTRATOR
        )
        
        # Add to session to get ID
        from src.models.db import db
        db.session.add(admin)
        db.session.commit()
        
        # Create admin profile
        admin_profile = Administrator(
            user_id=admin.user_id,
            admin_level='system',
            department='IT'
        )
        
        db.session.add(admin_profile)
        db.session.commit()
        
        # Refresh user to get relationship
        admin = User.query.get(admin.user_id)
        
        # Check relationship
        assert admin.administrator is not None
        assert admin.administrator.admin_level == 'system'
        assert admin.administrator.department == 'IT'

def test_faculty_profile(app):
    """Test that faculty profile can be created and linked to a user."""
    with app.app_context():
        # Create a test faculty user
        faculty = User(
            username='facultyprofile',
            email='facultyprofile@example.com',
            password='pass',
            role=UserRole.FACULTY_STAFF
        )
        
        # Add to session to get ID
        from src.models.db import db
        db.session.add(faculty)
        db.session.commit()
        
        # Create faculty profile
        faculty_profile = FacultyStaff(
            user_id=faculty.user_id,
            department='Computer Science',
            position='Professor',
            office_location='Building A, Room 101'
        )
        
        db.session.add(faculty_profile)
        db.session.commit()
        
        # Refresh user to get relationship
        faculty = User.query.get(faculty.user_id)
        
        # Check relationship
        assert faculty.faculty_staff is not None
        assert faculty.faculty_staff.department == 'Computer Science'
        assert faculty.faculty_staff.position == 'Professor'
        assert faculty.faculty_staff.office_location == 'Building A, Room 101'

def test_student_profile(app):
    """Test that student profile can be created and linked to a user."""
    with app.app_context():
        # Create a test student user
        student = User(
            username='studentprofile',
            email='studentprofile@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        
        # Add to session to get ID
        from src.models.db import db
        db.session.add(student)
        db.session.commit()
        
        # Create student profile
        student_profile = Student(
            user_id=student.user_id,
            student_number='S12345',
            major='Computer Science',
            graduation_year=2025
        )
        
        db.session.add(student_profile)
        db.session.commit()
        
        # Refresh user to get relationship
        student = User.query.get(student.user_id)
        
        # Check relationship
        assert student.student is not None
        assert student.student.student_number == 'S12345'
        assert student.student.major == 'Computer Science'
        assert student.student.graduation_year == 2025
