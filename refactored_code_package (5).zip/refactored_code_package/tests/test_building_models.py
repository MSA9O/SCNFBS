"""
Unit tests for building and room models in the Smart Campus Navigation and Facility Booking System.

This module contains tests for the Building, Room, and related models.
"""

import pytest
from src.models.building import Building, Room, RoomType, RoomStatus
from src.models.equipment import Equipment, EquipmentStatus, RoomEquipment
from datetime import datetime

def test_building_creation(app):
    """Test that a building can be created with correct attributes."""
    with app.app_context():
        # Create a test building
        building = Building(
            name='Test Building',
            address='123 Test Street',
            floors=5,
            description='A test building',
            latitude=40.7128,
            longitude=-74.0060
        )
        
        # Check attributes
        assert building.name == 'Test Building'
        assert building.address == '123 Test Street'
        assert building.floors == 5
        assert building.description == 'A test building'
        assert building.latitude == 40.7128
        assert building.longitude == -74.0060

def test_room_creation(app):
    """Test that a room can be created with correct attributes."""
    with app.app_context():
        # Create a test building first
        from src.models.db import db
        building = Building(
            name='Room Test Building',
            address='456 Room Street',
            floors=3,
            description='Building for room tests'
        )
        db.session.add(building)
        db.session.commit()
        
        # Create a test room
        room = Room(
            building_id=building.building_id,
            room_number='101',
            name='Test Room',
            floor=1,
            capacity=30,
            room_type=RoomType.CLASSROOM,
            status=RoomStatus.AVAILABLE,
            is_accessible=True,
            description='A test classroom'
        )
        
        db.session.add(room)
        db.session.commit()
        
        # Check attributes
        assert room.room_number == '101'
        assert room.name == 'Test Room'
        assert room.floor == 1
        assert room.capacity == 30
        assert room.room_type == RoomType.CLASSROOM
        assert room.status == RoomStatus.AVAILABLE
        assert room.is_accessible == True
        assert room.description == 'A test classroom'
        
        # Check relationship with building
        assert room.building_id == building.building_id
        assert room.building.name == 'Room Test Building'

def test_room_availability(app):
    """Test the room availability checking functionality."""
    with app.app_context():
        from src.models.db import db
        from src.models.reservation import Reservation, ReservationStatus
        from src.models.user import User, UserRole
        
        # Create test building and room
        building = Building(name='Availability Test Building', address='789 Avail St', floors=2)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='A101',
            name='Availability Test Room',
            floor=1,
            capacity=20,
            room_type=RoomType.MEETING_ROOM,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        # Create test user
        user = User(
            username='availtest',
            email='avail@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        db.session.add(user)
        db.session.commit()
        
        # Test availability with no reservations
        start_time = datetime(2025, 6, 1, 10, 0)
        end_time = datetime(2025, 6, 1, 11, 0)
        
        assert room.check_availability(start_time, end_time) == True
        
        # Create a reservation
        reservation = Reservation(
            user_id=user.user_id,
            room_id=room.room_id,
            start_time=datetime(2025, 6, 1, 9, 0),
            end_time=datetime(2025, 6, 1, 10, 30),
            purpose='Test meeting',
            status=ReservationStatus.CONFIRMED
        )
        db.session.add(reservation)
        db.session.commit()
        
        # Test overlapping time
        assert room.check_availability(start_time, end_time) == False
        
        # Test non-overlapping time
        later_start = datetime(2025, 6, 1, 11, 0)
        later_end = datetime(2025, 6, 1, 12, 0)
        assert room.check_availability(later_start, later_end) == True
        
        # Test with room under maintenance
        room.status = RoomStatus.MAINTENANCE
        db.session.commit()
        
        assert room.check_availability(later_start, later_end) == False

def test_equipment_creation(app):
    """Test that equipment can be created and assigned to rooms."""
    with app.app_context():
        from src.models.db import db
        
        # Create test building and room
        building = Building(name='Equipment Test Building', address='101 Equip St', floors=1)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='E101',
            name='Equipment Test Room',
            floor=1,
            capacity=15,
            room_type=RoomType.LABORATORY,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        db.session.commit()
        
        # Create equipment
        projector = Equipment(
            name='Projector',
            description='HD Projector',
            status=EquipmentStatus.OPERATIONAL
        )
        
        computer = Equipment(
            name='Computer',
            description='Desktop Computer',
            status=EquipmentStatus.OPERATIONAL
        )
        
        db.session.add_all([projector, computer])
        db.session.commit()
        
        # Assign equipment to room
        room_projector = RoomEquipment(
            room_id=room.room_id,
            equipment_id=projector.equipment_id,
            quantity=1
        )
        
        room_computer = RoomEquipment(
            room_id=room.room_id,
            equipment_id=computer.equipment_id,
            quantity=10
        )
        
        db.session.add_all([room_projector, room_computer])
        db.session.commit()
        
        # Check relationships
        assert len(room.equipment) == 2
        
        # Check equipment quantities
        equipment_dict = {re.equipment_id: re.quantity for re in room.equipment}
        assert equipment_dict[projector.equipment_id] == 1
        assert equipment_dict[computer.equipment_id] == 10
