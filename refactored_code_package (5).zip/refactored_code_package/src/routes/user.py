from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.db import db 
from src.models.user import User, UserRole

user_routes_blueprint = Blueprint('user', __name__)

@user_routes_blueprint.route('/profile')
@login_required
def profile():
    """View user profile"""
    return render_template('user/profile.html')

@user_routes_blueprint.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    """Edit user profile"""
    if request.method == 'POST':
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        
        if not email:
            flash('Email is required', 'error')
            return render_template('user/edit_profile.html', UserRole=UserRole)
        # Check if email already exists for another user
        existing_user_with_email = User.query.filter(User.email == email, User.user_id != current_user.user_id).first() # type: ignore
        if existing_user_with_email:
            flash('This email address is already in use by another account.', 'error')
            return render_template('user/edit_profile.html', UserRole=UserRole)

        try:
            current_user.email = email
            current_user.phone_number = phone_number
            
            # Update role-specific information
            # Ensure related objects (student, faculty_staff) exist
            if current_user.role == UserRole.STUDENT and current_user.student:
                current_user.student.major = request.form.get('major', current_user.student.major)
                current_user.student.graduation_year = request.form.get('graduation_year', current_user.student.graduation_year)
                # Add student_number if it should be editable by the student
                # current_user.student.student_number = request.form.get('student_number', current_user.student.student_number)
            elif current_user.role == UserRole.FACULTY_STAFF and current_user.faculty_staff:
                current_user.faculty_staff.department = request.form.get('department', current_user.faculty_staff.department)
                current_user.faculty_staff.position = request.form.get('position', current_user.faculty_staff.position)
                current_user.faculty_staff.office_location = request.form.get('office_location', current_user.faculty_staff.office_location)
            # Administrator role-specific fields can be added here if they are user-editable
            # elif current_user.role == UserRole.ADMINISTRATOR and current_user.administrator:
            #    current_user.administrator.department = request.form.get('admin_department', current_user.administrator.department)


            db.session.commit()
            flash('Profile updated successfully', 'success')
            return redirect(url_for('user_routes.profile'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred updating profile: {str(e)}', 'error')
        return render_template('user/edit_profile.html', UserRole=UserRole)

    return render_template('user/edit_profile.html', UserRole=UserRole)

@user_routes_blueprint.route('/bookings')
@login_required
def bookings():
    """View user's bookings"""
    return redirect(url_for('booking.my_reservations'))

@user_routes_blueprint.route('/preferences', methods=['GET', 'POST'])
@login_required
def preferences():
    """User preferences"""
    if request.method == 'POST':
        # Handle preference updates
        try:
            # Example: update notification preferences
            # To implement this, you'd need a UserPreference model or fields on User model.
            db.session.commit()
            flash('Preferences updated successfully', 'success')
            return redirect(url_for('user.preferences'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    return render_template('user/preferences.html')