"""
MySQL Setup Guide for Smart Campus Navigation and Facility Booking System

This guide provides detailed instructions for setting up and configuring 
the MySQL database for the SCNFBS application.
"""

# MySQL Setup Guide for SCNFBS

## Prerequisites

- MySQL Server 8.0 or higher installed
- MySQL client or command-line tools
- Database administration privileges

## Database Setup

### 1. Create the Database

Connect to your MySQL server and create a new database:

```sql
CREATE DATABASE tictactoe;
```

### 2. Configure Database Connection

The application is configured to connect to MySQL using the following parameters:

```python
mysql.connector.connect(
    host="localhost",
    user="root",
    password="Mohamed@123",
    database="tictactoe"
)
```

If you need to modify these settings, update the connection parameters in:
- `src/models/db.py` - For the direct MySQL connector
- `src/main.py` - For the SQLAlchemy URI

### 3. Database Initialization

The application will automatically create all necessary tables when first run. 
Alternatively, you can manually initialize the database using the provided SQL schema:

```bash
mysql -u root -p tictactoe < database_schema.sql
```

## Database Schema

The application uses the following main tables:

- `users` - User accounts and authentication
- `administrators`, `faculty_staff`, `students` - Role-specific user data
- `buildings` - Campus buildings information
- `rooms` - Rooms within buildings
- `equipment` - Available equipment
- `room_equipment` - Equipment assigned to rooms
- `reservations` - Room bookings
- `booking_policies` - Rules for room reservations
- `locations` - Navigation points
- `paths` - Navigation paths between locations
- `navigation_history` - User navigation requests

## Troubleshooting

### Connection Issues

If you encounter connection issues:

1. Verify MySQL server is running:
   ```bash
   sudo systemctl status mysql
   ```

2. Check credentials and permissions:
   ```sql
   CREATE USER 'root'@'localhost' IDENTIFIED BY 'Mohamed@123';
   GRANT ALL PRIVILEGES ON tictactoe.* TO 'root'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. Test connection from command line:
   ```bash
   mysql -u root -p -h localhost tictactoe
   ```

### Schema Issues

If tables are not created properly:

1. Check application logs for errors
2. Manually run the schema creation script:
   ```bash
   mysql -u root -p tictactoe < database_schema.sql
   ```

## Using Direct MySQL Queries

The application supports both SQLAlchemy ORM and direct MySQL connector queries.

Example of using direct MySQL connector:

```python
from src.models.db import get_db_connection

def execute_custom_query():
    try:
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE status = 'active'")
            results = cursor.fetchall()
            cursor.close()
            conn.close()
            return results
        return None
    except Exception as e:
        print(f"Error executing custom query: {str(e)}")
        return None
```

## Data Backup and Restore

### Backup Database

```bash
mysqldump -u root -p tictactoe > tictactoe_backup.sql
```

### Restore Database

```bash
mysql -u root -p tictactoe < tictactoe_backup.sql
```
