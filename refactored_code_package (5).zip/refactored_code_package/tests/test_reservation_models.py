"""
Unit tests for reservation models in the Smart Campus Navigation and Facility Booking System.

This module contains tests for the Reservation, BookingPolicy, and related models.
"""

import pytest
from src.models.reservation import Reservation, ReservationStatus, BookingPolicy, WaitlistEntry
from src.models.building import Building, Room, RoomType, RoomStatus
from src.models.user import User, UserRole
from datetime import datetime, time

def test_reservation_creation(app):
    """Test that a reservation can be created with correct attributes."""
    with app.app_context():
        from src.models.db import db
        
        # Create test building and room
        building = Building(name='Reservation Test Building', address='123 Res St', floors=2)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='R101',
            name='Reservation Test Room',
            floor=1,
            capacity=20,
            room_type=RoomType.MEETING_ROOM,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        # Create test user
        user = User(
            username='restest',
            email='res@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        db.session.add(user)
        db.session.commit()
        
        # Create reservation
        start_time = datetime(2025, 6, 1, 10, 0)
        end_time = datetime(2025, 6, 1, 11, 0)
        
        reservation = Reservation(
            user_id=user.user_id,
            room_id=room.room_id,
            start_time=start_time,
            end_time=end_time,
            purpose='Test meeting',
            status=ReservationStatus.CONFIRMED
        )
        
        db.session.add(reservation)
        db.session.commit()
        
        # Check attributes
        assert reservation.user_id == user.user_id
        assert reservation.room_id == room.room_id
        assert reservation.start_time == start_time
        assert reservation.end_time == end_time
        assert reservation.purpose == 'Test meeting'
        assert reservation.status == ReservationStatus.CONFIRMED
        
        # Check relationships
        assert reservation.user.username == 'restest'
        assert reservation.room.name == 'Reservation Test Room'

def test_reservation_cancel(app):
    """Test reservation cancellation functionality."""
    with app.app_context():
        from src.models.db import db
        
        # Create test building, room, user, and reservation
        building = Building(name='Cancel Test Building', address='456 Cancel St', floors=1)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='C101',
            name='Cancel Test Room',
            floor=1,
            capacity=10,
            room_type=RoomType.STUDY_SPACE,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        user = User(
            username='canceltest',
            email='cancel@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        db.session.add(user)
        db.session.commit()
        
        # Create reservation
        reservation = Reservation(
            user_id=user.user_id,
            room_id=room.room_id,
            start_time=datetime(2025, 7, 1, 14, 0),
            end_time=datetime(2025, 7, 1, 15, 0),
            purpose='Cancellation test',
            status=ReservationStatus.CONFIRMED
        )
        
        db.session.add(reservation)
        db.session.commit()
        
        # Test cancellation
        assert reservation.status == ReservationStatus.CONFIRMED
        result = reservation.cancel()
        assert result == True
        assert reservation.status == ReservationStatus.CANCELED
        
        # Test canceling already canceled reservation
        result = reservation.cancel()
        assert result == False
        assert reservation.status == ReservationStatus.CANCELED

def test_booking_policy(app):
    """Test booking policy validation functionality."""
    with app.app_context():
        from src.models.db import db
        
        # Create test building, room, and users
        building = Building(name='Policy Test Building', address='789 Policy St', floors=1)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='P101',
            name='Policy Test Room',
            floor=1,
            capacity=30,
            room_type=RoomType.CLASSROOM,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        student = User(
            username='policytest_student',
            email='policy_student@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        
        faculty = User(
            username='policytest_faculty',
            email='policy_faculty@example.com',
            password='pass',
            role=UserRole.FACULTY_STAFF
        )
        
        db.session.add_all([student, faculty])
        db.session.commit()
        
        # Create booking policy
        policy = BookingPolicy(
            name='Test Policy',
            description='Policy for testing',
            max_duration_minutes=120,
            advance_booking_days=14,
            start_time=time(8, 0),
            end_time=time(18, 0),
            applicable_roles='faculty',
            applicable_room_types='classroom,lab'
        )
        
        db.session.add(policy)
        db.session.commit()
        
        # Test policy validation - faculty booking classroom (should be allowed)
        start = datetime(2025, 6, 1, 10, 0)
        end = datetime(2025, 6, 1, 11, 30)  # 90 minutes
        
        assert policy.is_allowed(faculty, room, start, end) == True
        
        # Test policy validation - student booking classroom (should be denied due to role)
        assert policy.is_allowed(student, room, start, end) == False
        
        # Test policy validation - faculty booking too long (should be denied)
        long_end = datetime(2025, 6, 1, 13, 0)  # 180 minutes
        assert policy.is_allowed(faculty, room, start, long_end) == False
        
        # Test policy validation - faculty booking outside hours (should be denied)
        early_start = datetime(2025, 6, 1, 7, 0)
        early_end = datetime(2025, 6, 1, 8, 30)
        assert policy.is_allowed(faculty, room, early_start, early_end) == False
        
        # Test policy validation - faculty booking too far in advance (should be denied)
        far_future = datetime.now() + timedelta(days=30)
        far_future_end = far_future + timedelta(hours=1)
        assert policy.is_allowed(faculty, room, far_future, far_future_end) == False

def test_waitlist_entry(app):
    """Test waitlist entry functionality."""
    with app.app_context():
        from src.models.db import db
        
        # Create test building, room, and user
        building = Building(name='Waitlist Test Building', address='101 Wait St', floors=1)
        db.session.add(building)
        db.session.commit()
        
        room = Room(
            building_id=building.building_id,
            room_number='W101',
            name='Waitlist Test Room',
            floor=1,
            capacity=15,
            room_type=RoomType.MEETING_ROOM,
            status=RoomStatus.AVAILABLE
        )
        db.session.add(room)
        
        user = User(
            username='waitlisttest',
            email='waitlist@example.com',
            password='pass',
            role=UserRole.STUDENT
        )
        db.session.add(user)
        db.session.commit()
        
        # Create waitlist entry
        start_time = datetime(2025, 8, 1, 10, 0)
        end_time = datetime(2025, 8, 1, 11, 0)
        
        waitlist = WaitlistEntry(
            user_id=user.user_id,
            room_id=room.room_id,
            requested_start_time=start_time,
            requested_end_time=end_time,
            priority=1
        )
        
        db.session.add(waitlist)
        db.session.commit()
        
        # Check attributes
        assert waitlist.user_id == user.user_id
        assert waitlist.room_id == room.room_id
        assert waitlist.requested_start_time == start_time
        assert waitlist.requested_end_time == end_time
        assert waitlist.priority == 1
        assert waitlist.status == 'waiting'
        
        # Test notification when room becomes available
        result = waitlist.notify_if_available()
        assert result == True  # Room should be available
        assert waitlist.status == 'notified'
        
        # Create a reservation for the room
        reservation = Reservation(
            user_id=user.user_id,
            room_id=room.room_id,
            start_time=start_time,
            end_time=end_time,
            purpose='Test reservation',
            status=ReservationStatus.CONFIRMED
        )
        
        db.session.add(reservation)
        db.session.commit()
        
        # Create another waitlist entry
        waitlist2 = WaitlistEntry(
            user_id=user.user_id,
            room_id=room.room_id,
            requested_start_time=start_time,
            requested_end_time=end_time,
            priority=2
        )
        
        db.session.add(waitlist2)
        db.session.commit()
        
        # Test notification when room is not available
        result = waitlist2.notify_if_available()
        assert result == False  # Room should not be available
        assert waitlist2.status == 'waiting'
