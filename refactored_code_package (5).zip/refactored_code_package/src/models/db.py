"""
Database configuration module for the Smart Campus Navigation and Facility Booking System.

This module initializes the SQLAlchemy database instance used throughout the application.
"""

from flask_sqlalchemy import SQLAlchemy
import mysql.connector

# Initialize SQLAlchemy
db = SQLAlchemy()

def get_db_connection():
    """
    Create a direct MySQL database connection using mysql.connector.
    
    This function provides direct database access for custom SQL queries
    when the SQLAlchemy ORM is not suitable.
    
    Returns:
        mysql.connector.connection: A connection to the MySQL database
    """
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Mohamed@123",
            database="scnfs_project",
        )
        return conn
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        return None
