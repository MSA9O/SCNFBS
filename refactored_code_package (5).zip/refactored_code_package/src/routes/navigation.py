from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.db import db
from src.models.building import Building 
from src.models.navigation import Location, Path, NavigationHistory, LocationType, NavigationStep, AccessPoint
from datetime import datetime

navigation = Blueprint('navigation', __name__)

@navigation.route('/')
def index():
    """Display campus map and navigation interface"""
    buildings = Building.query.all()
    return render_template('navigation/index.html', buildings=buildings)

@navigation.route('/search', methods=['GET', 'POST'])
def search_location():
    """Search for locations on campus"""
    if request.method == 'POST':
        query = request.form.get('query', '')
        
        if not query or len(query) < 2:
            flash('Please enter at least 2 characters for search', 'warning')
            return redirect(url_for('navigation.index'))
        
        # Search for matching locations
        locations = Location.query.filter(
            Location.name.ilike(f'%{query}%')
        ).all()
        
        # Search for matching buildings
        buildings = Building.query.filter(
            Building.name.ilike(f'%{query}%')
        ).all()
        
        return render_template('navigation/search_results.html', 
                              locations=locations, 
                              buildings=buildings,
                              query=query)
    
    # GET request redirects to index
    return redirect(url_for('navigation.index'))

@navigation.route('/building/<int:building_id>')
def view_building(building_id):
    """View building details and floor plans"""
    building = Building.query.get_or_404(building_id)
    
    # Get all locations in this building
    locations = Location.query.filter_by(building_id=building_id).all()
    
    return render_template('navigation/building.html', 
                          building=building,
                          locations=locations)

@navigation.route('/location/<int:location_id>')
def view_location(location_id):
    """View details of a specific location"""
    location = Location.query.get_or_404(location_id)
    
    return render_template('navigation/location.html', location=location)

@navigation.route('/directions', methods=['GET', 'POST'])
def get_directions():
    """Generate directions between two points"""
    if request.method == 'POST':
        start_id = request.form.get('start_location')
        end_id = request.form.get('end_location')
        accessibility = request.form.get('accessibility') == 'on'
        
        if not start_id or not end_id:
            flash('Start and end locations are required', 'error')
            return redirect(url_for('navigation.index'))
        
        try:
            start_location = Location.query.get(start_id)
            end_location = Location.query.get(end_id)
            
            if not start_location or not end_location:
                flash('Invalid locations selected', 'error')
                return redirect(url_for('navigation.index'))
            
            # In a real implementation, this would use a pathfinding algorithm
            # For the scaffold, we'll check if a direct path exists
            if accessibility:
                path_query = Path.query.filter(
                    Path.start_location_id == start_id,  # Use correct attribute
                    Path.end_location_id == end_id,      # Use correct attribute
                    Path.is_accessible == True
                )
            else:
                path_query = Path.query.filter(
                Path.start_location_id == start_id,
                Path.end_location_id == end_id   
                )
            path = path_query.first()
            
            if not path:
                flash('No direct path found between these locations', 'warning')
                return render_template('navigation/no_path.html', 
                                      start=start_location,
                                      end=end_location,
                                      accessibility=accessibility)
            
            # Get navigation steps
            steps = NavigationStep.query.filter(
                path_id=path.path_id
            ).order_by(NavigationStep.step_number).all()
            
            return render_template('navigation/directions.html',
                                  path=path,
                                  steps=steps,
                                  start=start_location,
                                  end=end_location)
            
        except Exception as e:
            flash(f'Error generating directions: {str(e)}', 'error')
            return redirect(url_for('navigation.index'))
    
    # GET request - show direction form
    all_locations = Location.query.order_by(Location.name).all()
    return render_template('navigation/get_directions.html', locations=all_locations)

@navigation.route('/api/locations')
def api_locations():
    """API endpoint to get all locations as JSON"""
    locations = Location.query.all()
    
    result = [{
        'id': loc.location_id,
        'name': loc.name,
        'building_id': loc.building_id if loc.building else None,
        'building_name': loc.building.name if loc.building else None,
        'floor': loc.floor,
        'type': loc.location_type.value if loc.location_type else None,
        'x_coordinate': loc.x_coordinate,
        'y_coordinate': loc.y_coordinate
    } for loc in locations]
    
    return jsonify(result)

@navigation.route('/api/paths')
def api_paths():
    """API endpoint to get all paths as JSON"""
    paths = Path.query.all()
    
    result = [{
        'id': path.path_id,
        'start_location_id': path.start_location_id,       # Use correct attribute
        'end_location_id': path.end_location_id,         # Use correct attribute
        'distance': path.distance_meters,                # Use correct attribute
        'estimated_time': path.estimated_time_seconds,   # Use correct attribute
        'path_type': path.path_type,
        'is_accessible': path.is_accessible,
        'geometry': path.path_geometry
    } for path in paths]
    
    return jsonify(result)

@navigation.route('/accessibility')
def accessibility_map():
    """View map with accessibility features highlighted"""
    # Get all accessible paths
    accessible_paths = Path.query.filter(Path.is_accessible == True).all()    
    # Get all access points
    access_points = AccessPoint.query.filter(AccessPoint.is_operational == True).all()    
    return render_template('navigation/accessibility.html',
                          paths=accessible_paths,
                          access_points=access_points)
