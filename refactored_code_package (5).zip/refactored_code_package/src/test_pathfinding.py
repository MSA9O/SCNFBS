"""
Unit tests for the pathfinding algorithm implementation.
"""

import unittest
import sys
import os
import math
from datetime import datetime

# Add the implementation directory to the path
sys.path.append('/home/ubuntu/implementation')

# Import the pathfinding module
from pathfinding import CampusGraph, PathNode

class MockLocation:
    """Mock Location class for testing."""
    def __init__(self, location_id, name, building_id=None, x_coordinate=0, y_coordinate=0, 
                 floor=1, location_type=None):
        self.location_id = location_id
        self.name = name
        self.building_id = building_id
        self.x_coordinate = x_coordinate
        self.y_coordinate = y_coordinate
        self.floor = floor
        self.location_type = location_type

class MockPath:
    """Mock Path class for testing."""
    def __init__(self, path_id, start_location_id, end_location_id, distance_meters, 
                 estimated_time_seconds, is_accessible=True, path_type="WALKWAY"):
        self.path_id = path_id
        self.start_location_id = start_location_id
        self.end_location_id = end_location_id
        self.distance_meters = distance_meters
        self.estimated_time_seconds = estimated_time_seconds
        self.is_accessible = is_accessible
        self.path_type = path_type
        self.steps = []

class TestPathfinding(unittest.TestCase):
    """Test cases for the pathfinding algorithm."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create a test graph
        self.graph = CampusGraph()
        
        # Create test locations
        # Building 1: Main Building
        self.loc1 = MockLocation(1, "Main Entrance", 1, 0, 0, 1, "ENTRANCE")
        self.loc2 = MockLocation(2, "Main Lobby", 1, 10, 0, 1, "ROOM")
        self.loc3 = MockLocation(3, "Elevator", 1, 20, 0, 1, "ELEVATOR")
        self.loc4 = MockLocation(4, "Room 101", 1, 30, 0, 1, "ROOM")
        self.loc5 = MockLocation(5, "Room 201", 1, 30, 0, 2, "ROOM")
        
        # Building 2: Library
        self.loc6 = MockLocation(6, "Library Entrance", 2, 0, 50, 1, "ENTRANCE")
        self.loc7 = MockLocation(7, "Library Desk", 2, 10, 50, 1, "ROOM")
        self.loc8 = MockLocation(8, "Study Area", 2, 20, 50, 1, "ROOM")
        
        # Outdoor locations
        self.loc9 = MockLocation(9, "Campus Center", None, 0, 25, 0, "OUTDOOR")
        self.loc10 = MockLocation(10, "Parking Lot", None, -20, 25, 0, "OUTDOOR")
        
        # Add locations to graph
        for loc in [self.loc1, self.loc2, self.loc3, self.loc4, self.loc5, 
                   self.loc6, self.loc7, self.loc8, self.loc9, self.loc10]:
            self.graph.add_location(loc)
        
        # Create paths between locations
        # Building 1 internal paths
        self.path1_2 = MockPath(1, 1, 2, 10, 12, True, "HALLWAY")
        self.path2_3 = MockPath(2, 2, 3, 10, 12, True, "HALLWAY")
        self.path3_4 = MockPath(3, 3, 4, 10, 12, True, "HALLWAY")
        self.path3_5 = MockPath(4, 3, 5, 15, 20, True, "ELEVATOR") # Elevator to 2nd floor
        
        # Building 2 internal paths
        self.path6_7 = MockPath(5, 6, 7, 10, 12, True, "HALLWAY")
        self.path7_8 = MockPath(6, 7, 8, 10, 12, True, "HALLWAY")
        
        # Outdoor paths
        self.path9_1 = MockPath(7, 9, 1, 25, 30, True, "WALKWAY") # Campus center to Main building
        self.path9_6 = MockPath(8, 9, 6, 25, 30, True, "WALKWAY") # Campus center to Library
        self.path10_9 = MockPath(9, 10, 9, 20, 24, True, "WALKWAY") # Parking to Campus center
        
        # Non-accessible path
        self.path4_8 = MockPath(10, 4, 8, 40, 50, False, "SHORTCUT") # Direct but not accessible
        
        # Add paths to graph
        for path in [self.path1_2, self.path2_3, self.path3_4, self.path3_5,
                    self.path6_7, self.path7_8, self.path9_1, self.path9_6,
                    self.path10_9, self.path4_8]:
            self.graph.add_path(path)
    
    def test_simple_path(self):
        """Test finding a simple path within a building."""
        path = self.graph.find_path(1, 4)
        self.assertIsNotNone(path)
        self.assertEqual(path['locations'], [1, 2, 3, 4])
        self.assertEqual(len(path['segments']), 3)
        self.assertEqual(path['total_distance'], 30)
        self.assertEqual(path['total_time'], 36)
        self.assertTrue(path['is_accessible'])
    
    def test_path_with_elevator(self):
        """Test finding a path that includes an elevator."""
        path = self.graph.find_path(1, 5)
        self.assertIsNotNone(path)
        self.assertEqual(path['locations'], [1, 2, 3, 5])
        self.assertEqual(path['total_distance'], 35)
        self.assertEqual(path['total_time'], 44)
        self.assertTrue(path['is_accessible'])
    
    def test_path_between_buildings(self):
        """Test finding a path between different buildings."""
        path = self.graph.find_path(1, 8)
        self.assertIsNotNone(path)
        # Expected path: Main Entrance -> Lobby -> Campus Center -> Library Entrance -> Library Desk -> Study Area
        self.assertEqual(path['locations'], [1, 2, 3, 4, 8])
        self.assertFalse(path['is_accessible'])  # Uses non-accessible shortcut
    
    def test_accessible_path_between_buildings(self):
        """Test finding an accessible path between buildings."""
        path = self.graph.find_path(1, 8, accessible_only=True)
        self.assertIsNotNone(path)
        # Expected path: Main Entrance -> Main Lobby -> Campus Center -> Library Entrance -> Library Desk -> Study Area
        # This should avoid the non-accessible shortcut
        self.assertNotIn(4, path['locations'])  # Should not use Room 101
        self.assertTrue(path['is_accessible'])
    
    def test_path_from_parking(self):
        """Test finding a path from parking lot to a building."""
        path = self.graph.find_path(10, 5)
        self.assertIsNotNone(path)
        # Expected path: Parking -> Campus Center -> Main Entrance -> Lobby -> Elevator -> Room 201
        self.assertEqual(path['locations'][0], 10)  # Start at parking
        self.assertEqual(path['locations'][-1], 5)  # End at Room 201
        self.assertTrue(path['is_accessible'])
    
    def test_nonexistent_path(self):
        """Test behavior when no path exists."""
        # Add a disconnected location
        disconnected = MockLocation(99, "Disconnected", None, 100, 100, 1, "ROOM")
        self.graph.add_location(disconnected)
        
        path = self.graph.find_path(1, 99)
        self.assertIsNone(path)
    
    def test_entry_points(self):
        """Test finding entry points for a building."""
        entry_points = self.graph.find_entry_points(1)
        self.assertEqual(len(entry_points), 1)
        self.assertEqual(entry_points[0], 1)  # Main Entrance
        
        entry_points = self.graph.find_entry_points(2)
        self.assertEqual(len(entry_points), 1)
        self.assertEqual(entry_points[0], 6)  # Library Entrance
    
    def test_optimal_entry_point(self):
        """Test finding the optimal entry point to a building."""
        # From parking lot, the optimal entry to Building 1 should be Main Entrance
        entry_point = self.graph.find_optimal_entry_point(10, 1)
        self.assertEqual(entry_point, 1)
        
        # From parking lot, the optimal entry to Building 2 should be Library Entrance
        entry_point = self.graph.find_optimal_entry_point(10, 2)
        self.assertEqual(entry_point, 6)

if __name__ == '__main__':
    unittest.main()
