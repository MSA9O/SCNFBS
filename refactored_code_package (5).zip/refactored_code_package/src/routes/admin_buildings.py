"""
Building and room management functionality for the admin panel.

This module contains routes for managing buildings and rooms in the admin panel,
including creating, viewing, and editing buildings and rooms.
"""

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.db import db
from src.models.building import Building, Room, RoomStatus, RoomType

# Import the admin_required decorator
from src.routes.admin import admin_required

admin_buildings = Blueprint('admin_buildings', __name__, url_prefix='/admin')

# Building Management
@admin_buildings.route('/buildings')
@admin_required
def buildings():
    """
    Display all buildings in the system.
    
    Returns:
        Rendered template with list of all buildings
    """
    try:
        buildings = Building.query.all()
        return render_template('admin/buildings/index.html', buildings=buildings)
    except Exception as e:
        flash(f'Error retrieving buildings: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_buildings.route('/buildings/new', methods=['GET', 'POST'])
@admin_required
def new_building():
    """
    Add a new building to the system.
    
    Returns:
        On GET: Rendered form for creating new building
        On POST: Redirect to buildings list after processing form
    """
    if request.method == 'POST':
        name = request.form.get('name')
        address = request.form.get('address')
        floors = request.form.get('floors')
        description = request.form.get('description')
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        
        if not name or not address or not floors:
            flash('Name, address, and floors are required', 'error')
            return render_template('admin/buildings/new.html')
        
        try:
            building = Building(
                name=name,
                address=address,
                floors=int(floors),
                description=description,
                latitude=float(latitude) if latitude else None,
                longitude=float(longitude) if longitude else None
            )
            
            db.session.add(building)
            db.session.commit()
            
            flash('Building added successfully', 'success')
            return redirect(url_for('admin_buildings.buildings'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    return render_template('admin/buildings/new.html')

@admin_buildings.route('/buildings/<int:building_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_building(building_id):
    """
    Edit an existing building.
    
    Args:
        building_id: ID of the building to edit
        
    Returns:
        On GET: Rendered form for editing building
        On POST: Redirect to buildings list after processing form
    """
    try:
        building = Building.query.get_or_404(building_id)
        
        if request.method == 'POST':
            name = request.form.get('name')
            address = request.form.get('address')
            floors = request.form.get('floors')
            description = request.form.get('description')
            latitude = request.form.get('latitude')
            longitude = request.form.get('longitude')
            
            if not name or not address or not floors:
                flash('Name, address, and floors are required', 'error')
                return render_template('admin/buildings/edit.html', building=building)
            
            try:
                building.name = name
                building.address = address
                building.floors = int(floors)
                building.description = description
                building.latitude = float(latitude) if latitude else None
                building.longitude = float(longitude) if longitude else None
                
                db.session.commit()
                
                flash('Building updated successfully', 'success')
                return redirect(url_for('admin_buildings.buildings'))
                
            except Exception as e:
                db.session.rollback()
                flash(f'An error occurred: {str(e)}', 'error')
        
        return render_template('admin/buildings/edit.html', building=building)
    except Exception as e:
        flash(f'Error accessing building: {str(e)}', 'error')
        return redirect(url_for('admin_buildings.buildings'))

# Room Management
@admin_buildings.route('/rooms')
@admin_required
def rooms():
    """
    Display all rooms in the system.
    
    Returns:
        Rendered template with list of all rooms
    """
    try:
        rooms = Room.query.all()
        return render_template('admin/rooms/index.html', rooms=rooms)
    except Exception as e:
        flash(f'Error retrieving rooms: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_buildings.route('/rooms/new', methods=['GET', 'POST'])
@admin_required
def new_room():
    """
    Add a new room to the system.
    
    Returns:
        On GET: Rendered form for creating new room
        On POST: Redirect to rooms list after processing form
    """
    if request.method == 'POST':
        building_id = request.form.get('building_id')
        room_number = request.form.get('room_number')
        name = request.form.get('name')
        floor = request.form.get('floor')
        capacity = request.form.get('capacity')
        room_type = request.form.get('room_type')
        is_accessible = 'is_accessible' in request.form
        description = request.form.get('description')
        
        if not building_id or not room_number or not name or not floor or not capacity or not room_type:
            flash('All required fields must be filled', 'error')
            buildings = Building.query.all()
            return render_template('admin/rooms/new.html', buildings=buildings)
        
        try:
            room = Room(
                building_id=int(building_id),
                room_number=room_number,
                name=name,
                floor=int(floor),
                capacity=int(capacity),
                room_type=RoomType(room_type),
                status=RoomStatus.AVAILABLE,
                is_accessible=is_accessible,
                description=description
            )
            
            db.session.add(room)
            db.session.commit()
            
            flash('Room added successfully', 'success')
            return redirect(url_for('admin_buildings.rooms'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    try:
        buildings = Building.query.all()
        return render_template('admin/rooms/new.html', buildings=buildings)
    except Exception as e:
        flash(f'Error retrieving buildings: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_buildings.route('/rooms/<int:room_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_room(room_id):
    """
    Edit an existing room.
    
    Args:
        room_id: ID of the room to edit
        
    Returns:
        On GET: Rendered form for editing room
        On POST: Redirect to rooms list after processing form
    """
    try:
        room = Room.query.get_or_404(room_id)
        
        if request.method == 'POST':
            building_id = request.form.get('building_id')
            room_number = request.form.get('room_number')
            name = request.form.get('name')
            floor = request.form.get('floor')
            capacity = request.form.get('capacity')
            room_type = request.form.get('room_type')
            status = request.form.get('status')
            is_accessible = 'is_accessible' in request.form
            description = request.form.get('description')
            
            if not building_id or not room_number or not name or not floor or not capacity or not room_type:
                flash('All required fields must be filled', 'error')
                buildings = Building.query.all()
                return render_template('admin/rooms/edit.html', room=room, buildings=buildings)
            
            try:
                room.building_id = int(building_id)
                room.room_number = room_number
                room.name = name
                room.floor = int(floor)
                room.capacity = int(capacity)
                room.room_type = RoomType(room_type)
                room.status = RoomStatus(status) if status else room.status
                room.is_accessible = is_accessible
                room.description = description
                
                db.session.commit()
                
                flash('Room updated successfully', 'success')
                return redirect(url_for('admin_buildings.rooms'))
                
            except Exception as e:
                db.session.rollback()
                flash(f'An error occurred: {str(e)}', 'error')
        
        buildings = Building.query.all()
        return render_template('admin/rooms/edit.html', room=room, buildings=buildings)
    except Exception as e:
        flash(f'Error accessing room: {str(e)}', 'error')
        return redirect(url_for('admin_buildings.rooms'))
