// Main JavaScript file for SCNFBS

document.addEventListener('DOMContentLoaded', function() {
    console.log('SCNFBS application initialized');
    
    // Flash message auto-dismiss
    const flashMessages = document.querySelectorAll('.flash');
    if (flashMessages.length > 0) {
        flashMessages.forEach(message => {
            setTimeout(() => {
                message.style.opacity = '0';
                setTimeout(() => {
                    // Remove the element from DOM after fade out
                    message.remove(); 
                }, 500); // Match transition duration
            }, 5000); // Dismiss after 5 seconds
        });
    }
    
    // Basic client-side form validation (enhancement to HTML5 required)
    // HTML5 'required' attribute handles most basic cases.
    // This JS validation is a fallback or can be extended for more complex rules.
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            const requiredFields = form.querySelectorAll('[required]');
            let firstInvalidField = null;
            let isValid = true;
            
            requiredFields.forEach(field => {
                // Check if field is visible (relevant for conditional fields)
                if (field.offsetWidth > 0 || field.offsetHeight > 0 || field.getClientRects().length > 0) {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.classList.add('error');
                        if (!firstInvalidField) {
                            firstInvalidField = field;
                        }
                    } else {
                        field.classList.remove('error');
                    }
                }
            });
            
            if (!isValid) {
                event.preventDefault(); // Stop form submission
                // Optionally, provide a more central error message
                // For example, find or create a specific div for form errors
                // alert('Please fill in all highlighted required fields.'); 
                if (firstInvalidField) {
                    firstInvalidField.focus(); // Focus the first invalid field
                }
            }
        });

        // Remove error class on input
        const allFields = form.querySelectorAll('input, select, textarea');
        allFields.forEach(field => {
            field.addEventListener('input', function() {
                if (this.classList.contains('error') && this.value.trim()) {
                    this.classList.remove('error');
                }
            });
        });
    });
});