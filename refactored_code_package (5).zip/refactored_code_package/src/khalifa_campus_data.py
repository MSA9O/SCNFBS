# khalifa_campus_data.py

# -- your old campus buildings --
OLD_BUILDINGS = [
    {"name":"M Building", "address":"Khalifa U Main Campus", "floors":2,
     "description":"West-wing academic block", "latitude":24.428500, "longitude":54.602800},
    {"name":"L Building", "address":"Khalifa U Main Campus", "floors":3,
     "description":"Central lecture hall",   "latitude":24.428600, "longitude":54.603100},
    {"name":"R Building", "address":"Khalifa U Main Campus", "floors":3,
     "description":"Research wing",          "latitude":24.428400, "longitude":54.602700},
    {"name":"G Building", "address":"Khalifa U Main Campus", "floors":3,
     "description":"Labs & workshops",       "latitude":24.428700, "longitude":54.603000},
    {"name":"K Building", "address":"Khalifa U Main Campus", "floors":2,
     "description":"Admin offices",          "latitude":24.428650, "longitude":54.603050},
    # Added S Building based on map
    {"name":"S Building", "address":"Khalifa U Main Campus", "floors":2, # Assuming 2 floors
     "description":"Student services or similar (estimate)", "latitude":24.428300, "longitude":54.602900} # Estimated coordinates
]

# -- new-campus expansion with updated floors --
NEW_BUILDINGS = [
    {"name":"Ibn Sina A Building",       "address":"Khalifa U New Campus", "floors":4, "description":"Expansion A", "latitude":24.447100, "longitude":54.394800},
    {"name":"Al Razi B Building",        "address":"Khalifa U New Campus", "floors":5, "description":"Expansion B", "latitude":24.447200, "longitude":54.395000},
    {"name":"Ibn Al Haytham C Building", "address":"Khalifa U New Campus", "floors":5, "description":"Expansion C", "latitude":24.447300, "longitude":54.395200},
    {"name":"Al Khwarizmi D Building",   "address":"Khalifa U New Campus", "floors":5, "description":"Expansion D", "latitude":24.447400, "longitude":54.395400},
    {"name":"Ibn Hayyan E Building",     "address":"Khalifa U New Campus", "floors":4, "description":"Expansion E", "latitude":24.447500, "longitude":54.395600},
]

# -- key locations --
CAMPUS_LOCATIONS = [
    {"building_name":"M Building",         "name":"Gate 2 Entrance",     "description":"West pedestrian gate",      "floor":0, "latitude":24.428550, "longitude":54.602750, "location_type":"entrance"},
    {"building_name":"L Building",         "name":"Gate 1 Entrance",     "description":"Main south gate",          "floor":0, "latitude":24.428350, "longitude":54.602900, "location_type":"entrance"},
    {"building_name":"Ibn Sina A Building","name":"Multistorey Parking", "description":"New campus car park",      "floor":0, "latitude":24.447000, "longitude":54.395100, "location_type":"poi"}, # Adjusted parking location slightly based on map (near A,B,C,D,E)
    {"building_name":"G Building",         "name":"Clinic",              "description":"Campus health clinic",     "floor":0, "latitude":24.428700, "longitude":54.603000, "location_type":"poi"},
    {"building_name":"L Building",         "name":"Assembly Point",      "description":"Emergency gathering point","floor":0, "latitude":24.428600, "longitude":54.603100, "location_type":"poi"},

    # New POIs from the image, associated with New Campus buildings
    # Google Maps ref: 24.447427, 54.394882 (near Al Khwarizmi D)
    # Building E is westernmost (higher longitude for these parts), A is easternmost (lower longitude)
    {"building_name":"Ibn Hayyan E Building",     "name":"Library (POI 1)",           "description":"Main campus library in new expansion", "floor":0, "latitude":24.447500, "longitude":54.395600, "location_type":"poi"},
    {"building_name":"Ibn Hayyan E Building",     "name":"Prayer Room (POI 5)",       "description":"Prayer facilities",                    "floor":0, "latitude":24.447480, "longitude":54.395650, "location_type":"poi"}, # Slightly offset from Library
    {"building_name":"Ibn Hayyan E Building",     "name":"Food Court (POI 4)",        "description":"Main food court area",                 "floor":0, "latitude":24.447550, "longitude":54.395500, "location_type":"poi"}, # West of E center
    {"building_name":"Al Khwarizmi D Building",   "name":"Multi purpose hall (POI 2)","description":"Multi-purpose event hall",           "floor":0, "latitude":24.447350, "longitude":54.395300, "location_type":"poi"}, # Between D & C
    {"building_name":"Ibn Al Haytham C Building", "name":"Auditorium (POI 3)",        "description":"Main campus auditorium",               "floor":0, "latitude":24.447250, "longitude":54.395100, "location_type":"poi"}, # Between C & B
]