"""
Fixed pathfinding module for campus navigation.

This module implements the A* pathfinding algorithm for finding optimal paths
between locations on campus, with support for accessibility requirements and
multiple entry points.
"""

import heapq
from typing import Dict, List, Set, Tuple, Optional, Callable
import math
from datetime import datetime

# Import models when integrating with the main application
# from src.models.navigation import Location, Path, NavigationStep, AccessPoint
# from src.models.db import db

class PathNode:
    """
    Node representation for pathfinding algorithm.
    
    Attributes:
        location_id: ID of the location this node represents
        g_score: Cost from start node to this node
        h_score: Heuristic estimate from this node to goal
        f_score: Total score (g_score + h_score)
        parent: Parent node in the path
    """
    def __init__(self, location_id: int, g_score: float = float('inf'), 
                 h_score: float = 0, parent = None):
        self.location_id = location_id
        self.g_score = g_score
        self.h_score = h_score
        self.f_score = g_score + h_score
        self.parent = parent
    
    def __lt__(self, other):
        """Comparison for priority queue ordering."""
        return self.f_score < other.f_score
    
    def __eq__(self, other):
        """Equality check based on location_id."""
        if not isinstance(other, PathNode):
            return False
        return self.location_id == other.location_id
    
    def __hash__(self):
        """Hash based on location_id for use in sets."""
        return hash(self.location_id)

class CampusGraph:
    """
    Graph representation of campus for pathfinding.
    
    Attributes:
        adjacency_list: Dictionary mapping location IDs to their connected locations
        locations: Dictionary of location objects by ID
        paths: Dictionary of path objects by (start_id, end_id) tuple
    """
    def __init__(self):
        self.adjacency_list = {}  # location_id -> [(neighbor_id, weight), ...]
        self.locations = {}       # location_id -> Location object
        self.paths = {}           # (start_id, end_id) -> Path object
    
    def add_location(self, location):
        """
        Add a location to the graph.
        
        Args:
            location: Location object to add
        """
        self.locations[location.location_id] = location
        if location.location_id not in self.adjacency_list:
            self.adjacency_list[location.location_id] = []
    
    def add_path(self, path):
        """
        Add a path between locations to the graph.
        
        Args:
            path: Path object connecting two locations
        """
        start_id = path.start_location_id
        end_id = path.end_location_id
        
        # Ensure locations exist in the graph
        if start_id not in self.adjacency_list:
            self.adjacency_list[start_id] = []
        if end_id not in self.adjacency_list:
            self.adjacency_list[end_id] = []
        
        # Add path to adjacency list (weight can be distance or time)
        weight = path.distance_meters
        self.adjacency_list[start_id].append((end_id, weight))
        
        # Store the path object for later reference
        self.paths[(start_id, end_id)] = path
        
        # If the path is bidirectional, add the reverse connection
        # This would depend on the campus model - some paths might be one-way
        # For now, assuming all paths are bidirectional
        self.adjacency_list[end_id].append((start_id, weight))
        self.paths[(end_id, start_id)] = path  # Store reverse path reference too
        
    def get_neighbors(self, location_id: int, accessible_only: bool = False) -> List[Tuple[int, float]]:
        """
        Get neighboring locations and path weights.
        
        Args:
            location_id: ID of the location to get neighbors for
            accessible_only: If True, only return accessible paths
            
        Returns:
            List of tuples (neighbor_id, weight)
        """
        if location_id not in self.adjacency_list:
            return []
        
        if not accessible_only:
            return self.adjacency_list[location_id]
        
        # Filter for accessible paths only
        accessible_neighbors = []
        for neighbor_id, weight in self.adjacency_list[location_id]:
            # Check both directions for the path
            path_key = (location_id, neighbor_id)
            reverse_key = (neighbor_id, location_id)
            
            if path_key in self.paths and self.paths[path_key].is_accessible:
                accessible_neighbors.append((neighbor_id, weight))
            elif reverse_key in self.paths and self.paths[reverse_key].is_accessible:
                accessible_neighbors.append((neighbor_id, weight))
        
        return accessible_neighbors
    
    def heuristic(self, location_id: int, goal_id: int) -> float:
        """
        Calculate heuristic distance between two locations.
        
        Args:
            location_id: Starting location ID
            goal_id: Goal location ID
            
        Returns:
            Estimated distance between locations
        """
        # If locations aren't in the graph, return a default value
        if location_id not in self.locations or goal_id not in self.locations:
            return 0
        
        # Get coordinates for both locations
        loc1 = self.locations[location_id]
        loc2 = self.locations[goal_id]
        
        # Calculate Euclidean distance if coordinates are available
        if hasattr(loc1, 'x_coordinate') and hasattr(loc2, 'x_coordinate'):
            return math.sqrt((loc2.x_coordinate - loc1.x_coordinate)**2 + 
                            (loc2.y_coordinate - loc1.y_coordinate)**2)
        
        # Fallback to a default value if coordinates aren't available
        return 0
    
    def find_entry_points(self, building_id: int) -> List[int]:
        """
        Find all entry points for a building.
        
        Args:
            building_id: ID of the building
            
        Returns:
            List of location IDs that are entry points to the building
        """
        entry_points = []
        
        for location_id, location in self.locations.items():
            # Check if location is in the specified building and is an entry point
            if (hasattr(location, 'building_id') and 
                location.building_id == building_id and
                hasattr(location, 'location_type') and
                location.location_type == 'ENTRANCE'):  # Assuming 'ENTRANCE' is the type for entry points
                entry_points.append(location_id)
        
        return entry_points
    
    def find_optimal_entry_point(self, current_location_id: int, building_id: int) -> Optional[int]:
        """
        Find the optimal entry point to a building from the current location.
        
        Args:
            current_location_id: ID of the current location
            building_id: ID of the target building
            
        Returns:
            ID of the optimal entry point, or None if no entry point is found
        """
        entry_points = self.find_entry_points(building_id)
        
        if not entry_points:
            return None
        
        # Find the closest entry point using A* for each entry point
        best_entry_point = None
        best_distance = float('inf')
        
        for entry_id in entry_points:
            path = self.find_path(current_location_id, entry_id)
            if path and path['total_distance'] < best_distance:
                best_distance = path['total_distance']
                best_entry_point = entry_id
        
        return best_entry_point

    def find_path(self, start_id: int, goal_id: int, accessible_only: bool = False) -> Optional[Dict]:
        """
        Find the shortest path between two locations using A* algorithm.
        
        Args:
            start_id: Starting location ID
            goal_id: Goal location ID
            accessible_only: If True, only use accessible paths
            
        Returns:
            Dictionary containing path information, or None if no path is found
        """
        if start_id not in self.adjacency_list or goal_id not in self.adjacency_list:
            return None
        
        # Initialize open and closed sets
        open_set = []
        closed_set = set()
        
        # Create start node
        start_node = PathNode(start_id, 0, self.heuristic(start_id, goal_id))
        
        # Add start node to open set
        heapq.heappush(open_set, start_node)
        
        # Track all nodes for path reconstruction
        all_nodes = {start_id: start_node}
        
        while open_set:
            # Get node with lowest f_score
            current = heapq.heappop(open_set)
            
            # If we've reached the goal, reconstruct and return the path
            if current.location_id == goal_id:
                return self._reconstruct_path(current)
            
            # Add current node to closed set
            closed_set.add(current.location_id)
            
            # Check all neighbors
            for neighbor_id, weight in self.get_neighbors(current.location_id, accessible_only):
                # Skip if neighbor is in closed set
                if neighbor_id in closed_set:
                    continue
                
                # Calculate tentative g_score
                tentative_g_score = current.g_score + weight
                
                # If neighbor is not in all_nodes or we found a better path
                if neighbor_id not in all_nodes or tentative_g_score < all_nodes[neighbor_id].g_score:
                    # Create or update neighbor node
                    h_score = self.heuristic(neighbor_id, goal_id)
                    neighbor_node = PathNode(neighbor_id, tentative_g_score, h_score, current)
                    all_nodes[neighbor_id] = neighbor_node
                    
                    # Add to open set if not already there
                    if not any(node.location_id == neighbor_id for node in open_set):
                        heapq.heappush(open_set, neighbor_node)
        
        # No path found
        return None
    
    def _reconstruct_path(self, goal_node: PathNode) -> Dict:
        """
        Reconstruct the path from start to goal.
        
        Args:
            goal_node: The goal node with parent references
            
        Returns:
            Dictionary containing path information
        """
        # Reconstruct the path by following parent pointers
        current = goal_node
        path_locations = []
        path_steps = []
        total_distance = 0
        total_time = 0
        
        while current:
            path_locations.insert(0, current.location_id)
            
            # If there's a parent, add the path information
            if current.parent:
                parent_id = current.parent.location_id
                path_key = (parent_id, current.location_id)
                reverse_key = (current.location_id, parent_id)
                
                # If we have the path object, use its data
                if path_key in self.paths:
                    path = self.paths[path_key]
                    total_distance += path.distance_meters
                    total_time += path.estimated_time_seconds
                    
                    # Get steps for this path segment if available
                    if hasattr(path, 'steps'):
                        for step in path.steps:
                            path_steps.insert(0, {
                                'instruction': step.instruction,
                                'distance': step.distance,
                                'time': step.estimated_time,
                                'icon': step.icon
                            })
                elif reverse_key in self.paths:
                    path = self.paths[reverse_key]
                    total_distance += path.distance_meters
                    total_time += path.estimated_time_seconds
                    
                    # Get steps for this path segment if available
                    if hasattr(path, 'steps'):
                        for step in path.steps:
                            path_steps.insert(0, {
                                'instruction': step.instruction,
                                'distance': step.distance,
                                'time': step.estimated_time,
                                'icon': step.icon
                            })
            
            current = current.parent
        
        # Create path segments between consecutive locations
        path_segments = []
        for i in range(len(path_locations) - 1):
            start_id = path_locations[i]
            end_id = path_locations[i + 1]
            path_key = (start_id, end_id)
            reverse_key = (end_id, start_id)
            
            if path_key in self.paths:
                path = self.paths[path_key]
                path_segments.append({
                    'start_id': start_id,
                    'end_id': end_id,
                    'distance': path.distance_meters,
                    'time': path.estimated_time_seconds,
                    'is_accessible': path.is_accessible,
                    'path_type': path.path_type
                })
            elif reverse_key in self.paths:
                path = self.paths[reverse_key]
                path_segments.append({
                    'start_id': start_id,
                    'end_id': end_id,
                    'distance': path.distance_meters,
                    'time': path.estimated_time_seconds,
                    'is_accessible': path.is_accessible,
                    'path_type': path.path_type
                })
        
        # If no steps were found from path objects, generate basic steps
        if not path_steps:
            for i, segment in enumerate(path_segments):
                start_name = self.locations[segment['start_id']].name if segment['start_id'] in self.locations else f"Location {segment['start_id']}"
                end_name = self.locations[segment['end_id']].name if segment['end_id'] in self.locations else f"Location {segment['end_id']}"
                
                path_steps.append({
                    'instruction': f"Go from {start_name} to {end_name}",
                    'distance': segment['distance'],
                    'time': segment['time'],
                    'icon': None
                })
        
        # Check if the entire path is accessible
        is_accessible = all(segment['is_accessible'] for segment in path_segments) if path_segments else False
        
        return {
            'locations': path_locations,
            'segments': path_segments,
            'steps': path_steps,
            'total_distance': total_distance,
            'total_time': total_time,
            'is_accessible': is_accessible
        }

def build_campus_graph_from_db(db_session):
    """
    Build a campus graph from database models.
    
    Args:
        db_session: SQLAlchemy database session
        
    Returns:
        CampusGraph object populated with locations and paths
    """
    from src.models.navigation import Location, Path
    
    graph = CampusGraph()
    
    # Add all locations to the graph
    locations = db_session.query(Location).all()
    for location in locations:
        graph.add_location(location)
    
    # Add all paths to the graph
    paths = db_session.query(Path).all()
    for path in paths:
        graph.add_path(path)
    
    return graph

def find_path_between_locations(start_id, end_id, accessible_only=False, db_session=None):
    """
    Find path between two locations, for use in the navigation controller.
    
    Args:
        start_id: Starting location ID
        end_id: Goal location ID
        accessible_only: If True, only use accessible paths
        db_session: SQLAlchemy database session
        
    Returns:
        Dictionary containing path information, or None if no path is found
    """
    # If db_session is provided, build graph from database
    if db_session:
        graph = build_campus_graph_from_db(db_session)
    else:
        # For testing without database
        graph = CampusGraph()
        # Would need to manually add locations and paths for testing
    
    # Find the path
    return graph.find_path(start_id, end_id, accessible_only)

def create_navigation_steps(path_result, db_session):
    """
    Create NavigationStep objects from path result.
    
    Args:
        path_result: Result from find_path
        db_session: SQLAlchemy database session
        
    Returns:
        List of NavigationStep objects
    """
    from src.models.navigation import NavigationStep, Path
    
    if not path_result:
        return []
    
    # Get the path object
    path = db_session.query(Path).filter_by(
        start_location_id=path_result['locations'][0],
        end_location_id=path_result['locations'][-1]
    ).first()
    
    if not path:
        # Create a new path if it doesn't exist
        from src.models.navigation import Path
        path = Path(
            start_location_id=path_result['locations'][0],
            end_location_id=path_result['locations'][-1],
            distance_meters=path_result['total_distance'],
            estimated_time_seconds=path_result['total_time'],
            is_accessible=path_result['is_accessible'],
            path_type='CALCULATED'
        )
        db_session.add(path)
        db_session.flush()  # Get the path_id
    
    # Create navigation steps
    steps = []
    for i, step_data in enumerate(path_result['steps']):
        step = NavigationStep(
            path_id=path.path_id,
            step_number=i + 1,
            instruction=step_data['instruction'],
            distance=step_data.get('distance'),
            estimated_time=step_data.get('time'),
            icon=step_data.get('icon')
        )
        steps.append(step)
        db_session.add(step)
    
    return steps

# Example usage:
# path = find_path_between_locations(1, 10, accessible_only=True, db_session=db.session)
# if path:
#     steps = create_navigation_steps(path, db.session)
#     db.session.commit()
