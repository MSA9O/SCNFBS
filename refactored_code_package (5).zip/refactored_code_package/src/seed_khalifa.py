# seed_khalifa.py
from src.main import create_app
from src.models.db import db
from src.models.building import Building
from src.models.navigation import Location, LocationType
from src import khalifa_campus_data as data

# Define allowed location type strings based on the values in your LocationType Enum
# These are the *string values* of your Enum members
ALLOWED_LOCATION_TYPE_VALUES = {lt.value for lt in LocationType}

app = create_app()

with app.app_context():
    # 1) seed buildings
    name2obj = {}
    print("Seeding buildings...")
    for b_data in data.OLD_BUILDINGS + data.NEW_BUILDINGS:
        obj = Building.query.filter_by(name=b_data["name"]).first()
        if not obj:
            print(f"  Creating building: {b_data['name']}")
            obj = Building(
                name=b_data["name"],
                address=b_data["address"],
                floors=b_data["floors"],
                description=b_data.get("description"),
                latitude=b_data.get("latitude"),      # Building model keeps lat/lon
                longitude=b_data.get("longitude"),    # Building model keeps lat/lon
                image_url=b_data.get("image_url")     # Use get for optional image_url
            )
            db.session.add(obj)
            db.session.flush() # Get ID if needed, though not strictly here
        else:
            print(f"  Building already exists: {b_data['name']}")
        name2obj[b_data["name"]] = obj
    db.session.commit()
    print("Buildings seeding complete.")

    # 2) seed locations / POIs
    print("\nSeeding locations (POIs, Entrances, etc.)...")
    for loc_data in data.CAMPUS_LOCATIONS:
        bldg = name2obj.get(loc_data["building_name"])
        if not bldg:
            print(f"❗ Unknown building '{loc_data['building_name']}' for location '{loc_data['name']}', skipping.")
            continue

        # skip if already exists (by name within the building)
        existing_loc = Location.query.filter_by(
            building_id=bldg.building_id,
            name=loc_data["name"]
        ).first()

        if existing_loc:
            print(f"  Location already exists: {loc_data['name']} in {bldg.name}")
            continue

        # Coerce location_type to a valid Enum member or default to POI
        raw_type_str = (loc_data.get("location_type") or "poi").lower()
        
        # Ensure the string value is valid for the LocationType Enum
        if raw_type_str not in ALLOWED_LOCATION_TYPE_VALUES:
            print(f"  Warning: Location type '{raw_type_str}' for '{loc_data['name']}' is not a valid LocationType enum value. Defaulting to 'poi'.")
            safe_type_str = "poi" # Default to 'poi' if not a valid enum string value
        else:
            safe_type_str = raw_type_str
        
        # Convert the string to the Enum member
        try:
            location_type_enum = LocationType(safe_type_str)
        except ValueError:
            print(f"  Critical Error: Could not convert '{safe_type_str}' to LocationType enum for '{loc_data['name']}'. Defaulting to POI.")
            location_type_enum = LocationType.POI


        print(f"  Creating location: {loc_data['name']} in {bldg.name}")
        new_loc = Location(
            building_id   = bldg.building_id,
            name          = loc_data["name"],
            description   = loc_data.get("description"),
            floor         = loc_data.get("floor", 0),
            # Map latitude/longitude from data to x_coordinate/y_coordinate in Location model
            x_coordinate  = loc_data.get("longitude"), # longitude maps to x_coordinate
            y_coordinate  = loc_data.get("latitude"),  # latitude maps to y_coordinate
            location_type = location_type_enum, # Assign the Enum member
            is_accessible = loc_data.get("is_accessible", True) # Default to True if not specified
        )
        db.session.add(new_loc)

    db.session.commit()
    print("✅ Khalifa campus buildings & locations seeded!")