from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify # Removed 'session' if not used elsewhere
from flask_login import login_required, current_user
from src.models.user import UserRole
from src.models.db import db
from src.models.building import Building, Room, RoomStatus
from src.models.reservation import Reservation, ReservationStatus, BookingPolicy, WaitlistEntry
from datetime import datetime, timedelta # Ensure datetime is imported

booking = Blueprint('booking', __name__)

@booking.route('/')
@login_required
def index():
    """Display booking dashboard with upcoming reservations"""
    upcoming_reservations = Reservation.query.filter_by(
        user_id=current_user.user_id
    ).filter(
        Reservation.start_time > datetime.utcnow(),
        Reservation.status != ReservationStatus.CANCELED
    ).order_by(Reservation.start_time).limit(5).all()
    
    return render_template('booking/index.html', reservations=upcoming_reservations)

@booking.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    """Search for available rooms based on criteria"""
    if request.method == 'POST':
        # Get combined date-time search parameters from the form
        start_datetime_str = request.form.get('start_datetime')
        end_datetime_str = request.form.get('end_datetime')
        
        # Get other search parameters
        capacity = request.form.get('capacity')
        building_id = request.form.get('building_id')
        room_type = request.form.get('room_type')
        
        # Validate required parameters
        if not start_datetime_str or not end_datetime_str:
            flash('Start and End date & time are required', 'error')
            return redirect(url_for('booking.search'))
        
        try:
            # Parse combined date and times
            # The dateFormat in Flatpickr for submission is "Y-m-d H:i" which is '%Y-%m-%d %H:%M'
            start_time = datetime.strptime(start_datetime_str, '%Y-%m-%d %H:%M')
            end_time = datetime.strptime(end_datetime_str, '%Y-%m-%d %H:%M')
            
            # Validate time range
            if start_time >= end_time:
                flash('End time must be after start time', 'error')
                return redirect(url_for('booking.search'))
            
            # Check if booking is in the past (using utcnow for comparison is good practice)
            if start_time < datetime.utcnow(): 
                flash('Cannot book in the past', 'error')
                return redirect(url_for('booking.search'))
            
            # Build query for available rooms
            query = Room.query.filter(Room.status == RoomStatus.AVAILABLE)
            
            # Apply filters
            if capacity:
                query = query.filter(Room.capacity >= int(capacity))
            if building_id: # Check if building_id is not empty or None before converting to int
                query = query.filter(Room.building_id == int(building_id))
            if room_type: # Check if room_type is not empty or None
                query = query.filter(Room.room_type == room_type) # Assuming room_type is already an enum or string value
            
            potential_rooms = query.all()
            available_rooms = []
            for room in potential_rooms:
                conflicting_reservations = Reservation.query.filter(
                    Reservation.room_id == room.room_id,
                    Reservation.status.in_([ReservationStatus.CONFIRMED, ReservationStatus.PENDING]), # type: ignore
                    Reservation.end_time > start_time,
                    Reservation.start_time < end_time
                ).count()
                if conflicting_reservations == 0:
                    available_rooms.append(room)
            
            # Prepare parameters for displaying the search criteria on the results page
            search_params_display = {
                'start_datetime_str': start_time.strftime('%B %d, %Y %I:%M %p'), # e.g., June 03, 2025 05:30 PM
                'end_datetime_str': end_time.strftime('%B %d, %Y %I:%M %p'),
                # You can add other searched parameters here if you want to display them
                'capacity_searched': capacity if capacity else "Any",
                # For building_name and room_type_display, you might need to query them if only IDs are passed
            }
            # Add building name if building_id was provided
            if building_id:
                searched_building = Building.query.get(int(building_id))
                search_params_display['building_name_searched'] = searched_building.name if searched_building else "N/A"
            else:
                search_params_display['building_name_searched'] = "Any"

            search_params_display['room_type_searched'] = room_type.capitalize() if room_type else "Any"


            return render_template('booking/search_results.html', 
                                  rooms=available_rooms, 
                                  # Pass the datetime objects if needed by the template for other logic
                                  start_time_obj=start_time, 
                                  end_time_obj=end_time,     
                                  search_params_display=search_params_display)
            
        except ValueError as e:
            flash(f'Invalid date or time format provided: {str(e)}', 'error')
            return redirect(url_for('booking.search'))
        except Exception as e: # Catch any other unexpected errors
            flash(f'An error occurred during search: {str(e)}', 'error')
            return redirect(url_for('booking.search'))

    # GET request - show search form
    buildings = Building.query.all()
    return render_template('booking/search.html', buildings=buildings)


# --- The rest of your booking.py file (book_room, my_reservations, etc.) ---
# Make sure the book_room and join_waitlist routes also adapt if they take date/time
# from forms that might now use the combined date-time picker.
# For now, assuming they are initiated from different contexts or use separate forms.

@booking.route('/book/<int:room_id>', methods=['GET', 'POST'])
@login_required
def book_room(room_id):
    room = Room.query.get_or_404(room_id)
    
    # Default times for the booking form if GET request or error
    # These would ideally come from the search if redirected from search_results
    # For simplicity, let's handle the POST logic assuming data is correctly submitted.
    # The form in booking/book.html would need its own date/time pickers.
    # Or, you'd pass start_time, end_time from search_results via query parameters.

    if request.method == 'POST':
        # If this form uses combined datetime pickers:
        start_datetime_str = request.form.get('start_datetime') # Assume booking/book.html has this field
        end_datetime_str = request.form.get('end_datetime')     # Assume booking/book.html has this field
        purpose = request.form.get('purpose')

        if not start_datetime_str or not end_datetime_str or not purpose:
            flash('All fields (start date/time, end date/time, purpose) are required', 'error')
            # Pass back any available data to re-populate form
            return render_template('booking/book.html', room=room, 
                                   start_datetime_val=start_datetime_str, 
                                   end_datetime_val=end_datetime_str, 
                                   purpose_val=purpose)
        
        try:
            start_time = datetime.strptime(start_datetime_str, '%Y-%m-%d %H:%M')
            end_time = datetime.strptime(end_datetime_str, '%Y-%m-%d %H:%M')
            
            if start_time >= end_time:
                flash('End time must be after start time', 'error')
                return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)
            
            if start_time < datetime.utcnow():
                flash('Cannot book in the past', 'error')
                return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)

            if not room.check_availability(start_time, end_time):
                flash('Room is not available for the selected time. Please try another time or search again.', 'error')
                return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)
            
            policies = BookingPolicy.query.all()
            allowed_by_policy = False
            if not policies:
                allowed_by_policy = True
            else:
                for policy in policies:
                    if policy.is_allowed(current_user, room, start_time, end_time):
                        allowed_by_policy = True
                        break
            
            if not allowed_by_policy:
                flash('This booking violates one or more booking policies.', 'error')
                return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)

            reservation = Reservation(
                user_id=current_user.user_id,
                room_id=room_id,
                start_time=start_time,
                end_time=end_time,
                purpose=purpose,
                status=ReservationStatus.CONFIRMED
            )
            db.session.add(reservation)
            db.session.commit()
            
            flash('Reservation confirmed successfully!', 'success')
            return redirect(url_for('booking.view_reservation', reservation_id=reservation.reservation_id))
            
        except ValueError:
            flash('Invalid date or time format submitted.', 'error')
            return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)
        except Exception as e:
            flash(f'An error occurred: {str(e)}', 'error')
            return render_template('booking/book.html', room=room, start_datetime_val=start_datetime_str, end_datetime_val=end_datetime_str, purpose_val=purpose)

    # GET request - show booking form
    # If navigating from search_results, you might pass start/end times as query params
    # Example: url_for('booking.book_room', room_id=room.room_id, start=start_time_obj, end=end_time_obj)
    # Then retrieve them here:
    start_val = request.args.get('start_datetime_val')
    end_val = request.args.get('end_datetime_val')
    return render_template('booking/book.html', room=room, start_datetime_val=start_val, end_datetime_val=end_val)


@booking.route('/reservations')
@login_required
def my_reservations():
    """View all user's reservations"""
    status = request.args.get('status')
    query = Reservation.query.filter_by(user_id=current_user.user_id)
    if status:
        try:
            query = query.filter_by(status=ReservationStatus(status))
        except ValueError:
            flash(f"Invalid status filter: {status}", "error")
            # Optionally, redirect or render with no status filter
    reservations = query.order_by(Reservation.start_time.desc()).all()
    return render_template('booking/my_reservations.html', reservations=reservations, now=datetime.utcnow())


@booking.route('/reservation/<int:reservation_id>')
@login_required
def view_reservation(reservation_id):
    """View details of a specific reservation"""
    reservation = Reservation.query.get_or_404(reservation_id)
    if reservation.user_id != current_user.user_id and current_user.role != UserRole.ADMINISTRATOR:
        flash('You do not have permission to view this reservation', 'error')
        return redirect(url_for('booking.my_reservations'))
    return render_template('booking/view_reservation.html', reservation=reservation)


@booking.route('/reservation/<int:reservation_id>/cancel', methods=['POST'])
@login_required
def cancel_reservation(reservation_id):
    """Cancel a reservation"""
    reservation = Reservation.query.get_or_404(reservation_id)
    if reservation.user_id != current_user.user_id and current_user.role != UserRole.ADMINISTRATOR:
        flash('You do not have permission to cancel this reservation', 'error')
        return redirect(url_for('booking.my_reservations'))
    
    if reservation.status in [ReservationStatus.COMPLETED, ReservationStatus.CANCELED] or reservation.start_time < datetime.utcnow():
        flash('This reservation cannot be canceled (either already past, completed, or canceled).', 'error')
        return redirect(url_for('booking.view_reservation', reservation_id=reservation_id))
    
    # Use the cancel method from the model if it handles db.session.commit()
    # For now, directly setting status and committing
    reservation.status = ReservationStatus.CANCELED
    reservation.updated_at = datetime.utcnow() # Manually update if not auto on status change
    db.session.commit()
    
    # Check waitlist (this logic seems fine)
    waitlist_entries = WaitlistEntry.query.filter_by(
        room_id=reservation.room_id,
        status='waiting'
    ).filter(
        WaitlistEntry.requested_end_time > reservation.start_time,
        WaitlistEntry.requested_start_time < reservation.end_time
    ).order_by(WaitlistEntry.priority, WaitlistEntry.created_at).all()
    
    for entry in waitlist_entries:
        if entry.room.check_availability(entry.requested_start_time, entry.requested_end_time):
            entry.status = 'notified' 
            # Here you would also typically send a notification (email, etc.)
            db.session.add(entry) 
    db.session.commit() # Commit changes to waitlist entries
    
    flash('Reservation canceled successfully', 'success')
    return redirect(url_for('booking.my_reservations'))


@booking.route('/waitlist/<int:room_id>', methods=['POST'])
@login_required
def join_waitlist(room_id):
    """Join waitlist for a room"""
    # Assume this form will also use combined date-time pickers
    start_datetime_str = request.form.get('start_datetime') # e.g., from search_results if a room is unavailable
    end_datetime_str = request.form.get('end_datetime')
    
    if not start_datetime_str or not end_datetime_str:
        flash('Start and End date & time are required to join the waitlist', 'error')
        # Redirect back to where they came from, ideally search results or room page
        # For now, redirecting to general search
        return redirect(request.referrer or url_for('booking.search')) 
    
    try:
        start_time = datetime.strptime(start_datetime_str, '%Y-%m-%d %H:%M')
        end_time = datetime.strptime(end_datetime_str, '%Y-%m-%d %H:%M')

        if start_time >= end_time:
            flash('End time must be after start time for waitlist request.', 'error')
            return redirect(request.referrer or url_for('booking.search'))
        
        if start_time < datetime.utcnow():
            flash('Cannot join waitlist for a past time slot.', 'error')
            return redirect(request.referrer or url_for('booking.search'))

        # Check if user already has an active reservation for this room at this time
        existing_reservation = Reservation.query.filter(
            Reservation.user_id == current_user.user_id,
            Reservation.room_id == room_id,
            Reservation.status.in_([ReservationStatus.CONFIRMED, ReservationStatus.PENDING]), # type: ignore
            Reservation.end_time > start_time,
            Reservation.start_time < end_time
        ).first()
        if existing_reservation:
            flash('You already have a reservation for this room at the selected time.', 'info')
            return redirect(url_for('booking.view_reservation', reservation_id=existing_reservation.reservation_id))

        # Check if user is already on waitlist for this exact slot
        existing_waitlist = WaitlistEntry.query.filter_by(
            user_id=current_user.user_id,
            room_id=room_id,
            requested_start_time=start_time,
            requested_end_time=end_time,
            status='waiting' # Only care if they are already 'waiting'
        ).first()
        if existing_waitlist:
            flash('You are already on the waitlist for this room and time.', 'info')
            return redirect(url_for('booking.my_waitlist'))

        waitlist_entry = WaitlistEntry(
            user_id=current_user.user_id,
            room_id=room_id,
            requested_start_time=start_time,
            requested_end_time=end_time,
            priority=0, 
            status='waiting'
        )
        db.session.add(waitlist_entry)
        db.session.commit()
        
        flash('You have been added to the waitlist successfully!', 'success')
        return redirect(url_for('booking.my_waitlist'))
        
    except ValueError:
        flash('Invalid date or time format for waitlist request.', 'error')
        return redirect(request.referrer or url_for('booking.search'))
    except Exception as e:
        flash(f'An error occurred while joining the waitlist: {str(e)}', 'error')
        return redirect(request.referrer or url_for('booking.search'))


@booking.route('/waitlist')
@login_required
def my_waitlist():
    """View user's waitlist entries"""
    waitlist_entries = WaitlistEntry.query.filter_by(
        user_id=current_user.user_id
    ).order_by(WaitlistEntry.created_at.desc()).all()
    return render_template('booking/my_waitlist.html', waitlist_entries=waitlist_entries)