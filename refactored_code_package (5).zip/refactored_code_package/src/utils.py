"""
Utility functions for common operations in the Smart Campus Navigation and Facility Booking System.

This module provides reusable utility functions for error handling, validation,
and other common operations used throughout the application.
"""

from flask import flash
import re
from datetime import datetime, timedelta

def validate_email(email):
    """
    Validate email format using regex pattern.
    
    Args:
        email: Email address to validate
        
    Returns:
        bool: True if email is valid, False otherwise
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_date_range(start_date, end_date, max_days=None):
    """
    Validate a date range.
    
    Args:
        start_date: Start date string in YYYY-MM-DD format
        end_date: End date string in YYYY-MM-DD format
        max_days: Maximum allowed days between dates (optional)
        
    Returns:
        tuple: (is_valid, error_message)
    """
    try:
        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        
        if start > end:
            return False, "Start date must be before end date"
            
        if max_days is not None:
            delta = end - start
            if delta.days > max_days:
                return False, f"Date range cannot exceed {max_days} days"
                
        return True, ""
    except ValueError:
        return False, "Invalid date format. Use YYYY-MM-DD"

def validate_time_range(start_time, end_time, min_duration_minutes=None):
    """
    Validate a time range.
    
    Args:
        start_time: Start time string in HH:MM format
        end_time: End time string in HH:MM format
        min_duration_minutes: Minimum allowed duration in minutes (optional)
        
    Returns:
        tuple: (is_valid, error_message)
    """
    try:
        start = datetime.strptime(start_time, '%H:%M').time()
        end = datetime.strptime(end_time, '%H:%M').time()
        
        if start >= end:
            return False, "Start time must be before end time"
            
        if min_duration_minutes is not None:
            # Convert times to datetime for comparison
            base_date = datetime.today().date()
            start_dt = datetime.combine(base_date, start)
            end_dt = datetime.combine(base_date, end)
            
            duration = (end_dt - start_dt).total_seconds() / 60
            if duration < min_duration_minutes:
                return False, f"Duration must be at least {min_duration_minutes} minutes"
                
        return True, ""
    except ValueError:
        return False, "Invalid time format. Use HH:MM"

def safe_db_operation(operation_func, error_message="Database operation failed", success_message=None):
    """
    Execute a database operation safely with proper error handling.
    
    Args:
        operation_func: Function that performs the database operation
        error_message: Message to flash on error
        success_message: Message to flash on success (optional)
        
    Returns:
        tuple: (success, result)
    """
    from src.models.db import db
    
    try:
        result = operation_func()
        db.session.commit()
        
        if success_message:
            flash(success_message, 'success')
            
        return True, result
    except Exception as e:
        db.session.rollback()
        detailed_error = f"{error_message}: {str(e)}"
        flash(detailed_error, 'error')
        print(detailed_error)  # Log the error
        return False, None

def sanitize_input(text):
    """
    Sanitize user input to prevent XSS and other injection attacks.
    
    Args:
        text: Input text to sanitize
        
    Returns:
        str: Sanitized text
    """
    if text is None:
        return None
        
    # Remove potentially dangerous HTML/script tags
    sanitized = re.sub(r'<[^>]*>', '', text)
    
    # Escape special characters
    sanitized = sanitized.replace('&', '&amp;')
    sanitized = sanitized.replace('<', '&lt;')
    sanitized = sanitized.replace('>', '&gt;')
    sanitized = sanitized.replace('"', '&quot;')
    sanitized = sanitized.replace("'", '&#x27;')
    
    return sanitized
