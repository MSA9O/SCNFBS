"""
User management functionality for the admin panel.

This module contains routes for managing users in the admin panel,
including viewing, editing, and managing user accounts.
"""

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.db import db
from src.models.user import User, UserRole, Administrator, FacultyStaff, Student

# Import the admin_required decorator
from src.routes.admin import admin_required

admin_users = Blueprint('admin_users', __name__, url_prefix='/admin/users')

@admin_users.route('/')
@admin_required
def users():
    """
    Display all users in the system.
    
    Returns:
        Rendered template with list of all users
    """
    try:
        users = User.query.all()
        return render_template('admin/users/index.html', users=users)
    except Exception as e:
        flash(f'Error retrieving users: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_users.route('/<int:user_id>')
@admin_required
def view_user(user_id):
    """
    View details for a specific user.
    
    Args:
        user_id: ID of the user to view
        
    Returns:
        Rendered template with user details
    """
    try:
        user = User.query.get_or_404(user_id)
        return render_template('admin/users/view.html', user=user)
    except Exception as e:
        flash(f'Error retrieving user: {str(e)}', 'error')
        return redirect(url_for('admin_users.users'))

@admin_users.route('/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_user(user_id):
    """
    Edit a user's information.
    
    Args:
        user_id: ID of the user to edit
        
    Returns:
        On GET: Rendered form for editing user
        On POST: Redirect to user details page after processing form
    """
    try:
        user = User.query.get_or_404(user_id)
        
        if request.method == 'POST':
            email = request.form.get('email')
            status = request.form.get('status')
            role = request.form.get('role')
            
            if not email:
                flash('Email is required', 'error')
                return render_template('admin/users/edit.html', user=user, UserRole=UserRole)
            
            try:
                user.email = email
                user.status = status

                # Handle role change and role-specific profile updates
                if role and role != user.role.value:
                    new_role = UserRole(role)
                    
                  # Remove old role-specific profile if it exists
                    if user.role == UserRole.STUDENT and user.student:
                        db.session.delete(user.student)
                    elif user.role == UserRole.FACULTY_STAFF and user.faculty_staff:
                        db.session.delete(user.faculty_staff)
                    elif user.role == UserRole.ADMINISTRATOR and user.administrator:
                        db.session.delete(user.administrator)
                    user.role = new_role
                    
                # Create new role-specific profile based on new_role
                    if new_role == UserRole.STUDENT:
                        student = Student(user_id=user.user_id, 
                                      student_number=request.form.get('student_number', 'N/A'), 
                                      major=request.form.get('major', 'N/A'))
                        db.session.add(student)
                    elif new_role == UserRole.FACULTY_STAFF:
                        faculty = FacultyStaff(user_id=user.user_id, 
                                           department=request.form.get('department', 'N/A'), 
                                           position=request.form.get('position', 'N/A'))
                        db.session.add(faculty)
                    elif new_role == UserRole.ADMINISTRATOR:
                        admin = Administrator(user_id=user.user_id, 
                                          admin_level=request.form.get('admin_level', 'default'))
                        db.session.add(admin)
                else:
                    # Update existing role-specific profile if role hasn't changed
                    if user.role == UserRole.STUDENT and user.student:
                        user.student.student_number = request.form.get('student_number', user.student.student_number)
                        user.student.major = request.form.get('major', user.student.major)
                    elif user.role == UserRole.FACULTY_STAFF and user.faculty_staff:
                        user.faculty_staff.department = request.form.get('department', user.faculty_staff.department)
                        user.faculty_staff.position = request.form.get('position', user.faculty_staff.position)
                    elif user.role == UserRole.ADMINISTRATOR and user.administrator:
                        user.administrator.admin_level = request.form.get('admin_level', user.administrator.admin_level)

                db.session.commit()
                flash('User updated successfully', 'success')
                return redirect(url_for('admin_users.view_user', user_id=user_id))
                
            except Exception as e:
                db.session.rollback()
                flash(f'An error occurred: {str(e)}', 'error')
        # For GET request or if POST had an error before commit
        return render_template('admin/users/edit.html', user=user, UserRole=UserRole)
    except Exception as e: # Catch exceptions accessing user or initial page load

        flash(f'Error accessing user: {str(e)}', 'error')
        return redirect(url_for('admin_users.users'))

@admin_users.route('/new', methods=['GET', 'POST'])
@admin_required
def new_user():
    """
    Create a new user.
    
    Returns:
        On GET: Rendered form for creating new user
        On POST: Redirect to users list after processing form
    """
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        
        if not username or not email or not password or not role:
            flash('All fields are required', 'error')
            return render_template('admin/users/new.html')
        
        try:
            # Check if user already exists
            existing_user = User.query.filter(
                (User.username == username) | (User.email == email) # type: ignore
            ).first()
            
            if existing_user:
                flash('Username or email already exists', 'error')
                return render_template('admin/users/new.html')
            
            # Create new user
            user_role = UserRole(role)
            new_user = User(
                username=username,
                email=email,
                password=password,
                role=user_role
            )
            
            db.session.add(new_user)
            db.session.flush()  # Get user_id without committing
            
        # Create role-specific profile
        # (assuming form fields are available in admin/users/new.html for these)
            if user_role == UserRole.STUDENT:
                student_number = request.form.get('student_number')
                major = request.form.get('major')
                graduation_year = request.form.get('graduation_year')
                if not student_number or not major: # Basic validation
                    db.session.rollback()
                    flash('Student number and major are required for student role.', 'error')
                    return render_template('admin/users/new.html', UserRole=UserRole) # Pass UserRole
                student = Student(user_id=new_user.user_id, student_number=student_number, major=major, graduation_year=graduation_year)
                db.session.add(student)
            elif user_role == UserRole.FACULTY_STAFF:
                department = request.form.get('department')
                position = request.form.get('position')
                if not department or not position: # Basic validation
                    db.session.rollback()
                    flash('Department and position are required for faculty/staff role.', 'error')
                    return render_template('admin/users/new.html', UserRole=UserRole) # Pass UserRole
                faculty = FacultyStaff(user_id=new_user.user_id, department=department, position=position)
                db.session.add(faculty)
            elif user_role == UserRole.ADMINISTRATOR:
                admin_level = request.form.get('admin_level', 'default') # Default if not provided
                department = request.form.get('admin_department') # Optional department for admin
                admin = Administrator(user_id=new_user.user_id, admin_level=admin_level, department=department)
                db.session.add(admin)
                
            db.session.commit()

            flash('User created successfully', 'success')
            return redirect(url_for('admin_users.users'))
            
        except ValueError as ve:
            db.session.rollback()
            flash(f'Invalid role selected: {str(ve)}', 'error')
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred creating user: {str(e)}', 'error')

    # Make sure to pass UserRole enum to the template for the role dropdown
    return render_template('admin/users/new.html', UserRole=UserRole)
