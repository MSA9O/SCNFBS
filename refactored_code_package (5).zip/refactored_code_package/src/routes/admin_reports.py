"""
Reporting functionality for the admin panel.

This module contains routes for generating and exporting reports
in the admin panel, including usage reports and system statistics.
"""

from flask import Blueprint, render_template, redirect, url_for, flash, request, Response
from flask_login import login_required, current_user
from src.models.user import User
from src.models.db import db
from src.models.building import Building, Room
from src.models.reservation import Reservation, ReservationStatus, BookingPolicy
from datetime import datetime, timedelta
import csv
import io

# Import the admin_required decorator
from src.routes.admin import admin_required

admin_reports = Blueprint('admin_reports', __name__, url_prefix='/admin')

@admin_reports.route('/reports')
@admin_required
def reports():
    """
    Display the reports dashboard with available report options.
    
    Returns:
        Rendered template with report options
    """
    try:
        return render_template('admin/reports/index.html')
    except Exception as e:
        flash(f'Error accessing reports: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_reports.route('/reports/usage', methods=['GET', 'POST'])
@admin_required
def usage_report():
    """
    Generate usage reports for rooms and buildings.
    
    Returns:
        On GET: Rendered form for configuring report parameters
        On POST: Rendered report results or CSV download
    """
    if request.method == 'POST':
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        building_id = request.form.get('building_id')
        room_type = request.form.get('room_type')
        
        if not start_date or not end_date:
            flash('Start and end dates are required', 'error')
            try:
                buildings = Building.query.all()
                return render_template('admin/reports/usage.html', buildings=buildings)
            except Exception as e:
                flash(f'Error retrieving buildings: {str(e)}', 'error')
                return redirect(url_for('admin_reports.reports'))
        
        try:
            start = datetime.strptime(start_date, '%Y-%m-%d')
            end = datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)  # Include end date
            
            # Build query
            query = db.session.query(
                Reservation, Room, Building
            ).join(
                Room, Reservation.room_id == Room.room_id
            ).join(
                Building, Room.building_id == Building.building_id
            ).filter(
                Reservation.start_time >= start,
                Reservation.start_time < end,
                Reservation.status != ReservationStatus.CANCELED
            )
            
            if building_id:
                query = query.filter(Building.building_id == int(building_id))
            
            if room_type:
                query = query.filter(Room.room_type == room_type)
            
            results = query.all()
            
            # Generate CSV
            if 'export' in request.form:
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(['Reservation ID', 'Building', 'Room', 'Start Time', 'End Time', 'Duration (min)', 'User', 'Status'])
                
                for res, room, building in results:
                    duration = (res.end_time - res.start_time).total_seconds() / 60
                    writer.writerow([
                        res.reservation_id,
                        building.name,
                        room.name,
                        res.start_time.strftime('%Y-%m-%d %H:%M'),
                        res.end_time.strftime('%Y-%m-%d %H:%M'),
                        int(duration),
                        res.user.username,
                        res.status.value
                    ])
                
                output.seek(0)
                return Response(
                    output.getvalue(),
                    mimetype="text/csv",
                    headers={"Content-disposition": f"attachment; filename=usage_report_{start_date}_to_{end_date}.csv"}
                )
            
            return render_template('admin/reports/usage_results.html',
                                  results=results,
                                  start_date=start_date,
                                  end_date=end_date)
            
        except Exception as e:
            flash(f'An error occurred: {str(e)}', 'error')
    
    try:
        buildings = Building.query.all()
        return render_template('admin/reports/usage.html', buildings=buildings)
    except Exception as e:
        flash(f'Error retrieving buildings: {str(e)}', 'error')
        return redirect(url_for('admin_reports.reports'))

@admin_reports.route('/reports/statistics')
@admin_required
def statistics_report():
    """
    Generate system statistics report.
    
    Returns:
        Rendered template with system statistics
    """
    try:
        # Get counts for statistics
        user_count = db.session.query(db.func.count()).select_from(User).scalar()
        room_count = db.session.query(db.func.count()).select_from(Room).scalar()
        building_count = db.session.query(db.func.count()).select_from(Building).scalar()
        reservation_count = db.session.query(db.func.count()).select_from(Reservation).scalar()
        
        # Get reservation status counts
        status_counts = db.session.query(
            Reservation.status, db.func.count()
        ).group_by(Reservation.status).all()
        
        # Get room type counts
        room_type_counts = db.session.query(
            Room.room_type, db.func.count()
        ).group_by(Room.room_type).all()
        
        return render_template('admin/reports/statistics.html',
                              user_count=user_count,
                              room_count=room_count,
                              building_count=building_count,
                              reservation_count=reservation_count,
                              status_counts=status_counts,
                              room_type_counts=room_type_counts)
    except Exception as e:
        flash(f'Error generating statistics: {str(e)}', 'error')
        return redirect(url_for('admin_reports.reports'))

@admin_reports.route('/policies')
@admin_required
def policies():
    """
    Manage booking policies.
    
    Returns:
        Rendered template with list of all booking policies
    """
    try:
        policies = BookingPolicy.query.all()
        return render_template('admin/policies/index.html', policies=policies)
    except Exception as e:
        flash(f'Error retrieving policies: {str(e)}', 'error')
        return redirect(url_for('admin.index'))

@admin_reports.route('/policies/new', methods=['GET', 'POST'])
@admin_required
def new_policy():
    """
    Add a new booking policy.
    
    Returns:
        On GET: Rendered form for creating new policy
        On POST: Redirect to policies list after processing form
    """
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        max_duration = request.form.get('max_duration')
        advance_booking_days = request.form.get('advance_booking_days')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        applicable_roles = request.form.getlist('applicable_roles')
        applicable_room_types = request.form.getlist('applicable_room_types')
        
        if not name or not max_duration or not advance_booking_days or not start_time or not end_time:
            flash('All required fields must be filled', 'error')
            return render_template('admin/policies/new.html')
        
        try:
            policy = BookingPolicy(
                name=name,
                description=description,
                max_duration_minutes=int(max_duration),
                advance_booking_days=int(advance_booking_days),
                start_time=datetime.strptime(start_time, '%H:%M').time(),
                end_time=datetime.strptime(end_time, '%H:%M').time(),
                applicable_roles=','.join(applicable_roles) if applicable_roles else None,
                applicable_room_types=','.join(applicable_room_types) if applicable_room_types else None,
                created_by=current_user.user_id
            )
            
            db.session.add(policy)
            db.session.commit()
            
            flash('Booking policy added successfully', 'success')
            return redirect(url_for('admin_reports.policies'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'error')
    
    return render_template('admin/policies/new.html')
